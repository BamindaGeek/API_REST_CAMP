create
    definer = root@localhost procedure ps_Access(IN _accessId varchar(255), IN _pseudo varchar(100),
                                                 IN _password varchar(255), IN _expiredOn timestamp,
                                                 IN _membreId varchar(36), IN _status int(2), IN _action varchar(100))
BEGIN
    DECLARE membreId VARCHAR(36);
IF (_action='Insert') THEN
INSERT INTO access ( accessId, pseudo, password, createdOn, expiredOn, membreId, status)
    VALUE (_accessId, _pseudo, _password, NOW(), _expiredOn,_membreId, _status);
END IF;

IF (_action='UpdateById') THEN
UPDATE  access
SET
    password = _password,
    pseudo = _pseudo,
    expiredOn =_expiredOn,
    status = _statut
WHERE   accessId = _accessId ;
END IF;

IF (_action='DeleteById') THEN
UPDATE  access
SET status = 0
WHERE   accessId = _accessId ;
END IF;
IF (_action='SelectAll') THEN
SELECT m.*, a.accessId,a.expiredOn, a.password, a.pseudo, a.status as etatAccess
FROM access a
         INNER JOIN membre m ON m.membreId = a.membreId
WHERE a.status = 1;
END IF;
IF (_action='Connect') THEN
SET membreId = (SELECT a.membreId
                FROM access a
                         INNER JOIN membre m ON m.membreId = a.membreId
                WHERE a.status =_status AND password = _password AND (pseudo = _pseudo OR m.contact = _pseudo OR email = _pseudo));
IF membreId IS NOT NULL 
		THEN
SELECT m.*, a.password, a.pseudo, a.accessId, a.status as etatAccess,t.libelle as typemembre,co.comiteBaseId,co.libelle as LibelleCB,co.code as CodeCB,
       se.sectionId,se.libelle as LibelleSEC, se.code as CodeSEC,
       s.libelle as LibelleCommune,(SELECT COUNT(s.sectionId) FROM section s WHERE s.status = 1) as NbreSEC,
       (CASE t.libelle
            -- Section
            WHEN 'Secrétaire' THEN 
                (SELECT -1)
            -- Comité
            WHEN 'Animateur' THEN 
                (SELECT -1)
           -- Super Admin, Direction Executive
            ELSE (SELECT COUNT(s.sectionId) FROM section s WHERE s.status = 1)
           END) as NbreSEC,
       (CASE t.libelle
           -- Section
            WHEN 'Secrétaire' THEN (SELECT COUNT(c.comiteBaseId) FROM comitebase c INNER  JOIN section s3 on c.sectionId = s3.sectionId
                                    WHERE s3.sectionId = se.sectionId AND c.status=1)
           -- Comité
            WHEN 'Animateur' THEN (SELECT  -1)
           -- Super Admin, Direction Executive
            ELSE (SELECT COUNT(c.comiteBaseId) FROM comitebase c WHERE c.status = 1)
           END) as NbreCB,
       (CASE t.libelle
           -- Section
            WHEN 'Secrétaire' THEN (SELECT COUNT(m2.membreId) FROM membre m2 INNER JOIN affectationmembre a2 on m2.membreId = a2.membreId
                                                                             INNER JOIN comitebase c2 on a2.comiteBaseId = c2.comiteBaseId
                                                                             INNER JOIN section s2 on c2.sectionId = s2.sectionId
                                    WHERE s2.sectionId=se.sectionId AND m2.status = 1)
           -- Comité
            WHEN 'Animateur' THEN (SELECT COUNT(m2.membreId) FROM membre m2 INNER JOIN affectationmembre a2 on m2.membreId = a2.membreId
                                                                          INNER JOIN comitebase c2 on a2.comiteBaseId = c2.comiteBaseId
                                                            WHERE c2.comiteBaseId=co.comiteBaseId AND m2.status = 1)
           -- Super Admin, Direction Executive
            ELSE (SELECT COUNT(m1.membreId) FROM membre m1 WHERE m1.status = 1)
           END) as NbreML,
       (CASE t.libelle
           -- Section
            WHEN 'Secrétaire' THEN (SELECT  COUNT(af.affectationMissionId) FROM affectationmission af WHERE af.blocId=se.sectionId AND af.status=1)
           -- Comité
            WHEN 'Animateur' THEN (SELECT  COUNT(af.affectationMissionId) FROM affectationmission af WHERE af.comiteBaseId=co.comiteBaseId AND af.status=1)
           -- Super Admin, Direction Executive
            ELSE (SELECT COUNT(af.affectationMissionId) FROM affectationmission af WHERE af.status = 1 AND af.etat = 0)
           END) as NbreMI
FROM access a
         INNER JOIN membre m ON m.membreId = a.membreId
         INNER JOIN sousprefecture s on m.communeId = s.sousPrefectureId
         INNER JOIN typemembre t on m.typeMembreId = t.typeMembreId
         INNER JOIN affectationmembre af on m.membreId = af.membreId
         INNER JOIN comitebase co ON co.comiteBaseId = af.comiteBaseId
         INNER JOIN section se ON se.sectionId = co.sectionId
WHERE m.membreId = membreId;
ELSE
SELECT 1;
END IF;
END IF;
END;

