create
    definer = root@localhost procedure ps_Access(IN _accessId varchar(255), IN _pseudo varchar(100),
                                                 IN _password varchar(255), IN _expiredOn timestamp,
                                                 IN _membreId varchar(36), IN _status int(2), IN _action varchar(100))
BEGIN
    DECLARE membreId VARCHAR(36);
IF (_action='Insert') THEN
INSERT INTO access ( accessId, pseudo, password, createdOn, expiredOn, membreId, status)
    VALUE (_accessId, _pseudo, _password, NOW(), _expiredOn,_membreId, _status);
END IF;

IF (_action='UpdateById') THEN
UPDATE  access
SET
    password = _password,
    pseudo = _pseudo,
    expiredOn =_expiredOn,
    status = _statut
WHERE   accessId = _accessId ;
END IF;

IF (_action='DeleteById') THEN
UPDATE  access
SET status = 0
WHERE   accessId = _accessId ;
END IF;
IF (_action='SelectAll') THEN
SELECT m.*, a.accessId,a.expiredOn, a.password, a.pseudo, a.status as etatAccess
FROM access a
         INNER JOIN membre m ON m.membreId = a.membreId
WHERE a.status = 1;
END IF;
IF (_action='Connect') THEN
SET membreId = (SELECT a.membreId
                FROM access a
                         INNER JOIN membre m ON m.membreId = a.membreId
                WHERE a.status =_status AND password = _password AND (pseudo = _pseudo OR m.contact = _pseudo OR email = _pseudo));
IF membreId IS NOT NULL 
		THEN
SELECT m.*, a.password, a.pseudo, a.accessId, a.status as etatAccess,
       (CASE af.type
            WHEN 1 THEN "Cordinateur"
            WHEN 2 THEN "Animateur"
            ELSE "Administrateur"
           END) as typemembre,
       (CASE af.type
            WHEN 1 THEN co.libelle
            WHEN 2 THEN se.libelle
            ELSE 'RHDP'
           END) as bloc,
       (CASE af.type
            WHEN 1 THEN co.code
            WHEN 2 THEN se.code
            ELSE 'RHDP'
           END) as code
FROM access a
         INNER JOIN membre m ON m.membreId = a.membreId
         INNER JOIN affectation af ON af.acteurId = m.membreId
         LEFT JOIN comitebase co ON co.comiteBaseId = af.blocId
         LEFT JOIN section se ON se.sectionId = af.blocId
WHERE m.membreId = membreId;
ELSE
SELECT 1;
END IF;
END IF;
END;

