create
    definer = root@localhost procedure ps_Affectation(IN _affectationId varchar(36), IN _acteurId varchar(36),
                                                      IN _blocId varchar(36), IN _type int(2), IN _status int(2),
                                                      IN _createdBy varchar(36), IN _action varchar(100))
BEGIN
	#Routine body goes here...
	
	-- Insert une nouvelle Affectation
	IF (_action='Insert') THEN
		INSERT INTO affectation (affectationId, acteurId, blocId, type,status, createdBy)
		VALUES (_affectationId, _acteurId, _blocId, _type,_status, _createdBy);

        CASE _type
            -- Coordinateur de Region
            WHEN 1 THEN
                SELECT 0;
            -- Coordinateur de Departement
            WHEN 2 THEN
                SELECT 0;
            -- Coordinateur de Sous-Prefecture
            WHEN 3 THEN
                SELECT 0;
            -- Secrétaire de Section
            WHEN 4 THEN
                UPDATE membre
                SET
                    typeMembreId = (SELECT tm.typeMembreId FROM typemembre tm WHERE tm.libelle='Secrétaire')
                WHERE membreId = _acteurId;
            -- Animateur de Comite de base
            WHEN 5 THEN
                UPDATE membre
                SET
                    typeMembreId = (SELECT tm.typeMembreId FROM typemembre tm WHERE tm.libelle='Animateur')
                WHERE membreId = _acteurId;
            END CASE ;
	END IF;
	-- Updated une affectation
	IF (_action='UpdateById') THEN
		UPDATE affectation
		SET 
			affectationId = _affectationId,
			acteurId = _acteurId,
			blocId = _blocId,
			type = _type
		WHERE affectationId=_affectationId;
	END IF;
	-- Delete une affectation
    IF (_Action='DeleteById') THEN
			UPDATE affectation
			SET
				status=0 
			WHERE   affectationId =_affectationId ;

            UPDATE membre
            SET
                typeMembreId = (SELECT tm.typeMembreId FROM typemembre tm WHERE tm.libelle='Militant')
            WHERE membreId = (SELECT acteurId FROM affectation a WHERE a.affectationId=_affectationId);

		END IF;
	IF (_action='SelectAll') THEN
	    CASE _type
	        -- Coordinateur de Region
	        WHEN 1 THEN
                SELECT m2.*, r.regionId  as blocId, r.libelle, a2.affectationId,
                       ((SELECT  COUNT(af.affectationMissionId) FROM affectationmission af
                                                                         INNER JOIN section s on af.blocId = s.sectionId
                                                                         INNER JOIN sousprefecture s2 on s.communeId = s2.sousPrefectureId
                                                                         INNER JOIN departement d on s2.departementId = d.departementId
                         WHERE d.regionId=r.regionId AND af.status=1) +
                        (SELECT  COUNT(af.affectationMissionId) FROM affectationmission af
                                                                         INNER JOIN comitebase c on c.comiteBaseId= af.blocId
                                                                         INNER JOIN section s on s.sectionId = c.sectionId
                                                                         INNER JOIN sousprefecture s2 on s.communeId = s2.sousPrefectureId
                                                                         INNER JOIN departement d on s2.departementId = d.departementId
                         WHERE d.regionId=r.regionId AND af.status=1)) AS NbreMI,
                       a2.type,
                       (SELECT  COUNT(ss.sectionId) FROM section ss
                                                             INNER JOIN sousprefecture s4 on ss.communeId = s4.sousPrefectureId
                                                             INNER JOIN departement d2 on s4.departementId = d2.departementId
                        WHERE d2.regionId=r.regionId) AS NbreSEC,
                       (SELECT  COUNT(c.comiteBaseId) FROM comitebase c
                                                               INNER JOIN section s3 on c.sectionId = s3.sectionId
                                                               INNER JOIN sousprefecture s4 on s3.communeId = s4.sousPrefectureId
                                                               INNER JOIN departement d2 on s4.departementId = d2.departementId
                        WHERE d2.regionId=r.regionId) AS NbreCB,
                       (SELECT  COUNT(af.affectationMembreId) FROM affectationmembre af
                                                                       INNER  JOIN comitebase c2 on af.comiteBaseId = c2.comiteBaseId
                                                                       INNER  JOIN section s2 on c2.sectionId = s2.sectionId
                                                                       INNER JOIN sousprefecture s on s2.communeId = s.sousPrefectureId
                                                                       INNER JOIN departement d on s.departementId = d.departementId
                        WHERE d.regionId=r.regionId AND af.status=1) AS NbreML
                FROM region r
                         LEFT JOIN affectation a2 on r.regionId = a2.blocId AND a2.status=1
                         LEFT JOIN membre m2 on a2.acteurId = m2.membreId AND m2.status=1
                WHERE r.status=1 ;
            -- Coordinateur de Departement
            WHEN 2 THEN
                SELECT m2.*, d3.departementId  as blocId, d3.libelle, a2.affectationId,
                       ((SELECT  COUNT(af.affectationMissionId) FROM affectationmission af
                                                                         INNER JOIN section s on af.blocId = s.sectionId
                                                                         INNER JOIN sousprefecture s2 on s.communeId = s2.sousPrefectureId
                                                                         INNER JOIN departement d on s2.departementId = d.departementId
                         WHERE d.departementId=d3.departementId AND af.status=1) +
                        (SELECT  COUNT(af.affectationMissionId) FROM affectationmission af
                                                                         INNER JOIN comitebase c on c.comiteBaseId= af.blocId
                                                                         INNER JOIN section s on s.sectionId = c.sectionId
                                                                         INNER JOIN sousprefecture s2 on s.communeId = s2.sousPrefectureId
                                                                         INNER JOIN departement d on s2.departementId = d.departementId
                         WHERE d.departementId=d3.departementId AND af.status=1)) AS NbreMI,
                       a2.type,
                       (SELECT  COUNT(ss.sectionId) FROM section ss
                                                             INNER JOIN sousprefecture s4 on ss.communeId = s4.sousPrefectureId
                                                             INNER JOIN departement d2 on s4.departementId = d2.departementId
                        WHERE d2.departementId=d3.departementId) AS NbreSEC,
                       (SELECT  COUNT(c.comiteBaseId) FROM comitebase c
                                                               INNER JOIN section s3 on c.sectionId = s3.sectionId
                                                               INNER JOIN sousprefecture s4 on s3.communeId = s4.sousPrefectureId
                                                               INNER JOIN departement d2 on s4.departementId = d2.departementId
                        WHERE d2.departementId=d3.departementId) AS NbreCB,
                       (SELECT  COUNT(af.affectationMembreId) FROM affectationmembre af
                                                                       INNER  JOIN comitebase c2 on af.comiteBaseId = c2.comiteBaseId
                                                                       INNER  JOIN section s2 on c2.sectionId = s2.sectionId
                                                                       INNER JOIN sousprefecture s on s2.communeId = s.sousPrefectureId
                                                                       INNER JOIN departement d on s.departementId = d.departementId
                        WHERE d.departementId=d3.departementId AND af.status=1) AS NbreML
                FROM departement d3
                         LEFT JOIN affectation a2 on d3.departementId = a2.blocId AND a2.status=1
                         LEFT JOIN membre m2 on a2.acteurId = m2.membreId AND m2.status=1
                WHERE d3.status=1 ;
            -- Coordinateur de Sous-Prefecture
            WHEN 3 THEN
                SELECT m2.*, s5.sousPrefectureId  as blocId, s5.libelle, a2.affectationId,
                       ((SELECT  COUNT(af.affectationMissionId) FROM affectationmission af
                                                                         INNER JOIN section s on af.blocId = s.sectionId
                                                                         INNER JOIN sousprefecture s2 on s.communeId = s2.sousPrefectureId
                         WHERE s2.sousPrefectureId=s5.sousPrefectureId AND af.status=1) +
                        (SELECT  COUNT(af.affectationMissionId) FROM affectationmission af
                                                                         INNER JOIN comitebase c on c.comiteBaseId= af.blocId
                                                                         INNER JOIN section s on s.sectionId = c.sectionId
                                                                         INNER JOIN sousprefecture s2 on s.communeId = s2.sousPrefectureId
                         WHERE s2.sousPrefectureId=s5.sousPrefectureId AND af.status=1)) AS NbreMI,
                       a2.type,
                       (SELECT  COUNT(ss.sectionId) FROM section ss
                                                             INNER JOIN sousprefecture s4 on ss.communeId = s4.sousPrefectureId
                        WHERE s4.sousPrefectureId=s5.sousPrefectureId) AS NbreSEC,
                       (SELECT  COUNT(c.comiteBaseId) FROM comitebase c
                                                               INNER JOIN section s3 on c.sectionId = s3.sectionId
                                                               INNER JOIN sousprefecture s4 on s3.communeId = s4.sousPrefectureId
                        WHERE s4.sousPrefectureId=s5.sousPrefectureId) AS NbreCB,
                       (SELECT  COUNT(af.affectationMembreId) FROM affectationmembre af
                                                                       INNER  JOIN comitebase c2 on af.comiteBaseId = c2.comiteBaseId
                                                                       INNER  JOIN section s2 on c2.sectionId = s2.sectionId
                                                                       INNER JOIN sousprefecture s on s2.communeId = s.sousPrefectureId
                        WHERE s.sousPrefectureId=s5.sousPrefectureId AND af.status=1) AS NbreML
                FROM sousprefecture s5
                         LEFT JOIN affectation a2 on s5.sousPrefectureId = a2.blocId AND a2.status=1
                         LEFT JOIN membre m2 on a2.acteurId = m2.membreId AND m2.status=1
                WHERE s5.status=1 ;
            -- Coordinateur de Section
            WHEN 4 THEN
                SELECT m.*, s.sectionId  as blocId, s.libelle, a.affectationId, s.libelle as zone,sp.sousPrefectureId ,sp.libelle AS LibelleCommune,
                       (SELECT  COUNT(af.affectationMissionId) FROM affectationmission af WHERE af.blocId=s.sectionId AND af.status=1) AS NbreM,a.type,
                       (SELECT  COUNT(c.sectionId) FROM comitebase c WHERE c.sectionId=s.sectionId) AS NbreCB,
                       (SELECT  COUNT(af.affectationMembreId) FROM affectationmembre af 
                                                                INNER  JOIN comitebase c2 on af.comiteBaseId = c2.comiteBaseId
                                                                INNER  JOIN section s2 on c2.sectionId = s2.sectionId
                                                                WHERE c2.sectionId=s.sectionId AND af.status=1) AS NbreML
                FROM section s
                        INNER JOIN sousprefecture sp on s.communeId = sp.sousPrefectureId
                        LEFT JOIN affectation a on s.sectionId = a.blocId AND a.status=1
                        LEFT JOIN membre m on a.acteurId = m.membreId
                WHERE s.status=1 ;
            -- Animateur de Comite de base
            WHEN 5 THEN
                SELECT m.*, c.comiteBaseId as blocId, c.libelle, a.affectationId, s.libelle as zone ,sp.sousPrefectureId,sp.libelle AS LibelleCommune,
                       (SELECT  COUNT(af.affectationMembreId) FROM affectationmembre af WHERE af.comiteBaseId=c.comiteBaseId AND af.status=1) AS Nbre,a.type,
                       (SELECT  COUNT(af.blocId) FROM affectationmission af WHERE af.blocId=c.comiteBaseId AND af.status=1) AS NbreM
                FROM comitebase c
                         INNER JOIN section s ON s.sectionId = c.sectionId
                         INNER JOIN sousprefecture sp  ON s.communeId = sp.sousPrefectureId
                         LEFT JOIN affectation a on c.comiteBaseId = a.blocId AND a.status=1
                         LEFT JOIN membre m on a.acteurId = m.membreId
                WHERE c.status=1 ;
        END CASE ;
	END IF;

	IF (_action='SelectById') THEN
        CASE _type
            -- Coordinateur de Region
            WHEN 1 THEN
                SELECT m.*, r.regionId  as blocId, r.libelle, a.affectationId
                FROM affectation a
                         INNER JOIN region r ON a.blocId = r.regionId
                         INNER JOIN membre m  ON m.membreId = a.acteurId
                WHERE a.affectationId = _affectationID AND a.status=1;
            -- Coordinateur de Departement
            WHEN 2 THEN
                SELECT m.*, d.departementId  as blocId, d.libelle, a.affectationId
                FROM affectation a
                         INNER JOIN departement d ON a.blocId = d.departementId
                         INNER JOIN membre m  ON m.membreId = a.acteurId
                WHERE a.affectationId = _affectationID AND a.status=1;
            -- Coordinateur de Sous-Prefecture
            WHEN 3 THEN
                SELECT m.*, s.sousPrefectureId as blocId, s.libelle, a.affectationId
                FROM affectation a
                         INNER JOIN sousprefecture s ON a.blocId = s.sousPrefectureId
                         INNER JOIN membre m  ON m.membreId = a.acteurId
                WHERE a.affectationId = _affectationID AND a.status=1;
            -- Coordinateur de Section
            WHEN 4 THEN
                SELECT m.*, s.sectionId  as blocId, s.libelle, a.affectationId, s.libelle as zone,sp.sousPrefectureId ,sp.libelle AS LibelleCommune,
                       (SELECT  COUNT(af.affectationMissionId) FROM affectationmission af WHERE af.blocId=s.sectionId AND af.status=1) AS Nbre,a.type,
                       (SELECT  COUNT(c.sectionId) FROM comitebase c WHERE c.sectionId=s.sectionId) AS NbreCB
                FROM section s
                         INNER JOIN sousprefecture sp on s.communeId = sp.sousPrefectureId
                         LEFT JOIN affectation a on s.sectionId = a.blocId AND a.status=1
                         LEFT JOIN membre m on a.acteurId = m.membreId
                WHERE sp.sousPrefectureId = _affectationId AND s.status=1;
            -- Animateur de Comite de base
            WHEN 5 THEN
                SELECT m.*, c.comiteBaseId as blocId, c.libelle,c.code, a.affectationId, s.libelle as zone,s.sectionId,sp.sousPrefectureId,sp.libelle AS LibelleCommune,
                       (SELECT  COUNT(af.affectationMissionId) FROM affectationmission af WHERE af.blocId=c.comiteBaseId AND af.status=1) AS Nbre,a.type,
                       (SELECT count(a.affectationMembreId)
                        FROM affectationmembre a
                        WHERE a.comiteBaseId = c.comiteBaseId AND a.status=1) AS NbreML
                FROM comitebase c
                         INNER JOIN section s ON s.sectionId = c.sectionId
                         INNER JOIN sousprefecture sp  ON s.communeId = sp.sousPrefectureId
                         LEFT JOIN affectation a on c.comiteBaseId = a.blocId AND a.status=1
                         LEFT JOIN membre m on a.acteurId = m.membreId
                WHERE s.sectionId = _affectationID AND a.status=1;
            END CASE ;
	END IF;
END;

