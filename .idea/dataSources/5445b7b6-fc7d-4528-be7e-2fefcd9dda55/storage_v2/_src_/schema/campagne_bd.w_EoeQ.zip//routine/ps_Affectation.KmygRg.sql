create
    definer = root@localhost procedure ps_Affectation(IN _affectationId varchar(36), IN _acteurId varchar(36),
                                                      IN _blocId varchar(36), IN _type int(2), IN _status int(2),
                                                      IN _createdBy varchar(36), IN _action varchar(100))
BEGIN
	#Routine body goes here...
	
	-- Insert une nouvelle Affectation
	IF (_action='Insert') THEN
		INSERT INTO affectation (affectationId, acteurId, blocId, type,status, createdBy)
		VALUES (_affectationId, _acteurId, _blocId, _type,_status, _createdBy);
	END IF;
	-- Updated une affectation
	IF (_action='UpdateById') THEN
		UPDATE affectation
		SET 
			affectationId = _affectationId,
			acteurId = _acteurId,
			blocId = _blocId,
			type = _type
		WHERE affectationId=_affectationId;
	END IF;
	-- Delete une affectation
    IF (_Action='DeleteById') THEN
			UPDATE affectation
			SET
				status=0 
			WHERE   affectationId =_affectationId ;     
		END IF;
	IF (_action='SelectAll') THEN
	    CASE _type
	        -- Coordinateur de Region
	        WHEN 1 THEN
                SELECT m.*, r.regionId  as blocId, r.libelle, a.affectationId
                FROM affectation a
                        INNER JOIN region r ON a.blocId = r.regionId
                        INNER JOIN membre m  ON m.membreId = a.acteurId
                WHERE a.status=1;
            -- Coordinateur de Departement
            WHEN 2 THEN
                SELECT m.*, d.departementId  as blocId, d.libelle, a.affectationId
                FROM affectation a
                         INNER JOIN departement d ON a.blocId = d.departementId
                         INNER JOIN membre m  ON m.membreId = a.acteurId
                WHERE a.status=1;
            -- Coordinateur de Sous-Prefecture
            WHEN 3 THEN
                SELECT m.*, s.sousPrefectureId as blocId, s.libelle, a.affectationId
                FROM affectation a
                         INNER JOIN sousprefecture s ON a.blocId = s.sousPrefectureId
                         INNER JOIN membre m  ON m.membreId = a.acteurId
                WHERE a.status=1;
            -- Coordinateur de Section
            WHEN 4 THEN
                SELECT m.*, s.sectionId  as blocId, s.libelle, a.affectationId, sp.libelle as zone,sp.sousPrefectureId ,
                       (SELECT  COUNT(af.affectationMissionId) FROM affectationmission af WHERE af.blocId=s.sectionId AND af.status=1) AS Nbre,a.type,
                       (SELECT  COUNT(c.sectionId) FROM comitebase c WHERE c.sectionId=s.sectionId) AS NbreCB
                FROM section s
                        INNER JOIN sousprefecture sp on s.communeId = sp.sousPrefectureId
                        LEFT JOIN affectation a on s.sectionId = a.blocId AND a.status=1
                        LEFT JOIN membre m on a.acteurId = m.membreId
                WHERE s.status=1 ;
            -- Animateur de Comite de base
            WHEN 5 THEN
                SELECT m.*, c.comiteBaseId as blocId, c.libelle, a.affectationId, sp.libelle as zone ,sp.sousPrefectureId,sp.libelle AS LibelleCommune,
                       (SELECT  COUNT(af.affectationMembreId) FROM affectationmembre af WHERE af.comiteBaseId=c.comiteBaseId AND af.status=1) AS Nbre,a.type,
                       (SELECT  COUNT(af.blocId) FROM affectationmission af WHERE af.blocId=c.comiteBaseId AND af.status=1) AS NbreM
                FROM comitebase c
                         INNER JOIN section s ON s.sectionId = c.sectionId
                         INNER JOIN sousprefecture sp  ON s.communeId = sp.sousPrefectureId
                         LEFT JOIN affectation a on c.comiteBaseId = a.blocId AND a.status=1
                         LEFT JOIN membre m on a.acteurId = m.membreId
                WHERE c.status=1 ;
        END CASE ;
	END IF;

	IF (_action='SelectById') THEN
        CASE _type
            -- Coordinateur de Region
            WHEN 1 THEN
                SELECT m.*, r.regionId  as blocId, r.libelle, a.affectationId
                FROM affectation a
                         INNER JOIN region r ON a.blocId = r.regionId
                         INNER JOIN membre m  ON m.membreId = a.acteurId
                WHERE a.affectationId = _affectationID AND a.status=1;
            -- Coordinateur de Departement
            WHEN 2 THEN
                SELECT m.*, d.departementId  as blocId, d.libelle, a.affectationId
                FROM affectation a
                         INNER JOIN departement d ON a.blocId = d.departementId
                         INNER JOIN membre m  ON m.membreId = a.acteurId
                WHERE a.affectationId = _affectationID AND a.status=1;
            -- Coordinateur de Sous-Prefecture
            WHEN 3 THEN
                SELECT m.*, s.sousPrefectureId as blocId, s.libelle, a.affectationId
                FROM affectation a
                         INNER JOIN sousprefecture s ON a.blocId = s.sousPrefectureId
                         INNER JOIN membre m  ON m.membreId = a.acteurId
                WHERE a.affectationId = _affectationID AND a.status=1;
            -- Coordinateur de Section
            WHEN 4 THEN
                SELECT m.*, s.sectionId  as blocId, s.libelle, a.affectationId, sp.libelle as zone,sp.sousPrefectureId ,
                       (SELECT  COUNT(af.affectationMissionId) FROM affectationmission af WHERE af.blocId=s.sectionId AND af.status=1) AS Nbre,a.type,
                       (SELECT  COUNT(c.sectionId) FROM comitebase c WHERE c.sectionId=s.sectionId) AS NbreCB
                FROM section s
                         INNER JOIN sousprefecture sp on s.communeId = sp.sousPrefectureId
                         LEFT JOIN affectation a on s.sectionId = a.blocId AND a.status=1
                         LEFT JOIN membre m on a.acteurId = m.membreId
                WHERE sp.sousPrefectureId = _affectationId AND s.status=1;
            -- Animateur de Comite de base
            WHEN 5 THEN
                SELECT m.*, c.comiteBaseId as blocId, c.libelle,c.code, a.affectationId, s.libelle as zone,s.sectionId,sp.sousPrefectureId,sp.libelle AS LibelleCommune,
                       (SELECT  COUNT(af.affectationMissionId) FROM affectationmission af WHERE af.blocId=c.comiteBaseId AND af.status=1) AS Nbre,a.type,
                       (SELECT count(a.affectationMembreId)
                        FROM affectationmembre a
                        WHERE a.comiteBaseId = c.comiteBaseId AND a.status=1) AS NbreML
                FROM comitebase c
                         INNER JOIN section s ON s.sectionId = c.sectionId
                         INNER JOIN sousprefecture sp  ON s.communeId = sp.sousPrefectureId
                         LEFT JOIN affectation a on c.comiteBaseId = a.blocId AND a.status=1
                         LEFT JOIN membre m on a.acteurId = m.membreId
                WHERE s.sectionId = _affectationID AND a.status=1;
            END CASE ;
	END IF;
END;

