create
    definer = root@localhost procedure ps_AffectationMembre(IN _affectationMembreId varchar(36),
                                                            IN _membreId varchar(36), IN _comiteBaseId varchar(36),
                                                            IN _status varchar(36), IN _createdBy varchar(36),
                                                            IN _action varchar(100))
BEGIN

    #Routine body goes here...

    IF (_action='Insert') THEN

        INSERT INTO affectationmembre (affectationMembreId, membreId,comiteBaseId,status,createdBy)

        VALUES (_affectationMembreId, _membreId,_comiteBaseId,_status,_createdBy);

    END IF;

    IF (_action='UpdateById') THEN

        UPDATE affectationmembre

        SET
            membreId=_membreId,
            comiteBaseId = _comiteBaseId

        WHERE affectationMembreId=_affectationMembreId;

    END IF;

    IF (_action='DeleteById') THEN

        UPDATE affectationmembre

        SET

            status=0

        WHERE   affectationMembreId =_affectationMembreId ;

    END IF;




    IF (_action='SelectAll') THEN

        SELECT m.*,c.libelle ,am.affectationMembreId
        FROM affectationmembre am
                 INNER JOIN comitebase c on am.comiteBaseId = c.comiteBaseId
                 INNER JOIN membre m ON m.membreId = am.membreId
        where am.status=1;

    END IF;




    IF (_Action='SelectById') THEN

        SELECT m.*,c.libelle ,am.affectationMembreId
        FROM affectationmembre am
                 INNER JOIN comitebase c on am.comiteBaseId = c.comiteBaseId
                 INNER JOIN membre m ON m.membreId = am.membreId
        WHERE am.affectationMembreId = _affectationMembreId and am.status=1;

    END IF;
END;

