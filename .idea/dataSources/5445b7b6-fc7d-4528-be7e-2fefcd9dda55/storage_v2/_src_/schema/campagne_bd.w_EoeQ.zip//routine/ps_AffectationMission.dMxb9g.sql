create
    definer = root@localhost procedure ps_AffectationMission(IN _affectationMissionId varchar(36),
                                                             IN _missionId varchar(36), IN _blocId varchar(36),
                                                             IN _type int(2), IN _deadline varchar(36), IN _etat int(2),
                                                             IN _comment varchar(36), IN _status int(2),
                                                             IN _createdBy varchar(36), IN _action varchar(100))
BEGIN 

    #Routine body goes here... 

    IF (_action='Insert') THEN 

        INSERT INTO affectationMission (affectationMissionId, missionId,blocId,type,deadline,etat,comment,status, createdBy)

        VALUES (_affectationMissionId, _missionId,_blocId,_type,_deadline,_etat,_comment,_status, _createdBy);

    END IF; 

    IF (_action='UpdateById') THEN 

        UPDATE affectationMission 

        SET  
            missionId = _missionId,
            blocId=_blocId,
            type=_type,
            deadline=_deadline,
            etat=_etat,
            comment=_comment

        WHERE affectationMissionId=_affectationMissionId; 

    END IF; 

    IF (_action='DeleteById') THEN 

            UPDATE affectationMission 
            SET 
                status=0  
            WHERE   affectationMissionId =_affectationMissionId ; 

        END IF; 

        IF (_action='SelectAll') THEN
            CASE _type
                -- Coordinateur de Region
                WHEN 1 THEN
                    SELECT 0;
                -- Coordinateur de Departement
                WHEN 2 THEN
                    SELECT 0;
                -- Coordinateur de Sous-Prefecture
                WHEN 3 THEN
                    SELECT 0;
                -- Coordinateur de Section
                WHEN 4 THEN
                    SELECT af.*,mission.libelle AS Aff_lib,m.nom AS AffM_Membre
                    FROM affectationMission af
                             INNER JOIN mission ON mission.missionId = af.missionId
                             INNER JOIN section s on af.blocId = s.sectionId
                             LEFT JOIN affectation a ON s.sectionId = a.blocId AND a.status = 1
                             LEFT JOIN membre m ON m.membreId = a.acteurId
                    where af.status=1;

                -- Animateur de Comite de base
                WHEN 5 THEN
                    SELECT af.*,mission.libelle AS Aff_lib,m.nom AS AffM_Membre
                    FROM affectationMission af
                             INNER JOIN mission ON mission.missionId = af.missionId
                             INNER JOIN comitebase c on af.blocId = c.comiteBaseId
                             LEFT JOIN affectation a ON c.comiteBaseId = a.blocId AND a.status = 1
                             LEFT JOIN membre m ON m.membreId = a.acteurId
                    where af.status=1;
                END CASE ;
    END IF; 

    IF (_Action='SelectById') THEN
        CASE _type
            -- Coordinateur de Region
            WHEN 1 THEN
                SELECT 0;
            -- Coordinateur de Departement
            WHEN 2 THEN
                SELECT 0;
            -- Coordinateur de Sous-Prefecture
            WHEN 3 THEN
                SELECT 0;
            -- Coordinateur de Section
            WHEN 4 THEN
                SELECT af.*,mission.libelle AS Aff_lib,m.nom AS AffM_Membre
                FROM affectationMission af
                         INNER JOIN mission ON mission.missionId = af.missionId
                         INNER JOIN section s on af.blocId = s.sectionId
                         LEFT JOIN affectation a ON s.sectionId = a.blocId AND a.status = 1
                         LEFT JOIN membre m ON m.membreId = a.acteurId
                WHERE af.affectationMissionId = _affectationMissionId and af.status=1;

            -- Animateur de Comite de base
            WHEN 5 THEN
                SELECT af.*,mission.libelle AS Aff_lib,m.nom AS AffM_Membre
                FROM affectationMission af
                         INNER JOIN mission ON mission.missionId = af.missionId
                         INNER JOIN comitebase c on af.blocId = c.comiteBaseId
                         LEFT JOIN affectation a ON c.comiteBaseId = a.blocId AND a.status = 1
                         LEFT JOIN membre m ON m.membreId = a.acteurId
                WHERE af.affectationMissionId = _affectationMissionId and af.status=1;
            END CASE ;
    END IF;
END;

