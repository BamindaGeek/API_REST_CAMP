create
    definer = root@localhost procedure ps_AffectationObjectif(IN _affectationObjectifId varchar(36),
                                                              IN _objectifId varchar(36), IN _departementId varchar(36),
                                                              IN _valeur varchar(36), IN _deadline varchar(36),
                                                              IN _comment varchar(36), IN _status int(2),
                                                              IN _createdBy varchar(36), IN _action varchar(100))
BEGIN

    #Routine body goes here... 

    IF (_action='Insert') THEN

        INSERT INTO affectationObjectif (affectationObjectifId, objectifId,departementId,valeur,deadline,comment,status, createdBy)

        VALUES (_affectationObjectifId, _objectifId,_departementId,_valeur,_deadline,_comment,_status, _createdBy);

    END IF;

    IF (_action='UpdateById') THEN

        UPDATE affectationObjectif

        SET
            objectifId = _objectifId,
            departementId=_departementId,
            valeur=_valeur,
            deadline=_deadline,
            comment=_comment,
            comment=_comment

        WHERE affectationObjectifId=_affectationObjectifId;

    END IF;

    IF (_action='DeleteById') THEN

        UPDATE affectationObjectif
        SET
            status=0
        WHERE   affectationObjectifId =_affectationObjectifId ;

    END IF;

    IF (_action='SelectAll') THEN

        SELECT affectationObjectif.*,objectif.libelle AS LibelleObjectif,d.libelle AS LibelleDepartement
        FROM affectationObjectif
                 INNER JOIN objectif ON objectif.objectifId = affectationObjectif.objectifId
                 INNER JOIN departement d on affectationobjectif.departementId = d.departementId
        where affectationObjectif.status=1;

    END IF;

    IF (_action='SelectAllBy') THEN

        SELECT ao.*,o.libelle AS LibelleObjectif,d.libelle AS LibelleDepartement,
               (SELECT  COUNT(af.affectationMembreId) FROM affectationmembre af LEFT JOIN comitebase c on af.comiteBaseId = c.comiteBaseId AND c.status=1
                   LEFT JOIN section s on s.sectionId=c.sectionId and s.status=1
                   LEFT JOIN sousprefecture ss on ss.sousPrefectureId=s.communeId and ss.status=1
                   LEFT JOIN departement d2 on ss.departementId = d2.departementId AND d2.status=1
                   WHERE d2.departementId = d.departementId AND af.status = 1) AS NbreELEC, 
               (((SELECT  COUNT(af.affectationMembreId) FROM affectationmembre af LEFT JOIN comitebase c on af.comiteBaseId = c.comiteBaseId AND c.status=1
                                                                                                    LEFT JOIN section s on s.sectionId=c.sectionId and s.status=1
                                                                                                    LEFT JOIN sousprefecture ss on ss.sousPrefectureId=s.communeId and ss.status=1
                                                                                                    LEFT JOIN departement d2 on ss.departementId = d2.departementId AND d2.status=1
                                                                                               WHERE d2.departementId = d.departementId AND af.status = 1)/ao.valeur)*100) AS Taux
        FROM affectationObjectif ao
                 INNER JOIN objectif o ON o.objectifId = ao.objectifId
                 INNER JOIN departement d on ao.departementId = d.departementId
        where ao.status=1 AND ao.objectifId = _affectationObjectifId;

    END IF;

    IF (_Action='SelectById') THEN

        SELECT affectationObjectif.*,objectif.libelle AS LibelleObjectif,d.libelle AS LibelleDepartement
        FROM affectationObjectif
                 INNER JOIN objectif ON objectif.objectifId = affectationObjectif.objectifId
                 INNER JOIN departement d on affectationobjectif.departementId = d.departementId
        WHERE affectationObjectif.affectationObjectifId = _affectationObjectifId and affectationObjectif.status=1;

    END IF;
-- Liste des departements qui n'ont pas encore un objectif
    IF (_Action='Filtre') THEN
        SELECT d.*
        FROM departement d
        WHERE d.departementId NOT IN 
              (SELECT a.departementId FROM affectationobjectif a 
              WHERE a.objectifId=_affectationObjectifId);
    END IF;
END;

