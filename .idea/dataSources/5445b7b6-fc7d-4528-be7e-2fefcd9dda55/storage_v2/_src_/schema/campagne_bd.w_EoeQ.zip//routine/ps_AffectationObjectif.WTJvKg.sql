create
    definer = root@localhost procedure ps_AffectationObjectif(IN _affectationObjectifId varchar(36),
                                                              IN _objectifId varchar(36),
                                                              IN _sousPrefectureId varchar(36), IN _valeur varchar(36),
                                                              IN _deadline varchar(36), IN _comment varchar(36),
                                                              IN _status int(2), IN _createdBy varchar(36),
                                                              IN _action varchar(100))
BEGIN

    #Routine body goes here... 

    IF (_action='Insert') THEN

        INSERT INTO affectationObjectif (affectationObjectifId, objectifId,sousPrefectureId,valeur,deadline,comment,status, createdBy)

        VALUES (_affectationObjectifId, _objectifId,_sousPrefectureId,_valeur,_deadline,_comment,_status, _createdBy);

    END IF;

    IF (_action='UpdateById') THEN

        UPDATE affectationObjectif

        SET
            objectifId = _objectifId,
            sousPrefectureId=_sousPrefectureId,
            valeur=_valeur,
            deadline=_deadline,
            comment=_comment,
            comment=_comment

        WHERE affectationObjectifId=_affectationObjectifId;

    END IF;

    IF (_action='DeleteById') THEN

        UPDATE affectationObjectif
        SET
            status=0
        WHERE   affectationObjectifId =_affectationObjectifId ;

    END IF;

    IF (_action='SelectAll') THEN

        SELECT affectationObjectif.*,objectif.libelle AS LibelleObjectif,s.libelle AS LibelleCommune
        FROM affectationObjectif
                 INNER JOIN objectif ON objectif.objectifId = affectationObjectif.objectifId
                 INNER JOIN sousprefecture s on affectationobjectif.sousPrefectureId = s.sousPrefectureId
        where affectationObjectif.status=1;

    END IF;

    IF (_Action='SelectById') THEN

        SELECT affectationObjectif.*,objectif.libelle AS LibelleObjectif,s.libelle AS LibelleCommune
        FROM affectationObjectif
                 INNER JOIN objectif ON objectif.objectifId = affectationObjectif.objectifId
                 INNER JOIN sousprefecture s on affectationobjectif.sousPrefectureId = s.sousPrefectureId
        WHERE affectationObjectif.affectationObjectifId = _affectationObjectifId and affectationObjectif.status=1;

    END IF;
END;

