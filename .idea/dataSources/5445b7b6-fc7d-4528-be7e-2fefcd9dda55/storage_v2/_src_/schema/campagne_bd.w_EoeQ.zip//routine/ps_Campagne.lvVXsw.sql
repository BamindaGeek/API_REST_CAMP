create
    definer = root@localhost procedure ps_Campagne(IN _campagneId varchar(36), IN _libelle varchar(255),
                                                   IN _createdBy varchar(36), IN _action varchar(100))
BEGIN 

    #Routine body goes here... 

    IF (_action='Insert') THEN 

        INSERT INTO campagne (campagneId, libelle, createdBy) 

        VALUES (_campagneId, _libelle, _createdBy); 

    END IF; 

    IF (_action='UpdateById') THEN 

        UPDATE campagne 

        SET  

            campagneId = _campagneId, 

            libelle = _libelle

        WHERE campagneId=_campagneId; 

    END IF; 

    IF (_action='DeleteById') THEN 

            UPDATE campagne 

            SET 

                status=0  

            WHERE   campagneId =_campagneId; 

        END IF; 

 
 

        IF (_action='SelectAll') THEN 

            SELECT * FROM campagne
            Where status=1; 

    END IF; 

 
 

    IF (_action='SelectById') THEN 

            SELECT * FROM campagne 

                    WHERE campagne.campagneId = _campagneId
                    and  status=1; 

    END IF; 

 
 

     

END;

