create
    definer = root@localhost procedure ps_Checklist(IN _checklistId varchar(36), IN _affectationMissionId varchar(36),
                                                    IN _membreId varchar(36), IN _etat int(2), IN _comment varchar(36),
                                                    IN _status int(2), IN _createdBy varchar(36),
                                                    IN _action varchar(100))
BEGIN 

    #Routine body goes here... 

    IF (_action='Insert') THEN 
        INSERT INTO checklist (checklistId, affectationMissionId,membreId,etat,comment,status, createdBy) 
        VALUES (_checklistId, _affectationMissionId,_membreId, _etat,_comment,_status, _createdBy); 
    END IF; 

    IF (_action='UpdateById') THEN 

        UPDATE checklist 
        SET  
            checklistId = _checklistId, 
            affectationMissionId = _affectationMissionId,
            membreId=_membreId,
            etat=_etat,
            comment=_comment
        WHERE checklistId=_checklistId; 
    END IF; 

    IF (_Action='DeleteById') THEN 
            UPDATE checklist 
            SET 
                status=0  
            WHERE   checklistId =_checklistId ; 
        END IF; 

        IF (_Action='SelectAll') THEN 
            SELECT checklist.*,affectationMission.status AS Check_AfMi,membre.nom AS Check_Membre
            			FROM checklist
    		INNER JOIN affectationMission ON affectationMission.affectationMissionId = checklist.affectationMissionId
			INNER JOIN membre ON membre.membreId = checklist.membreId
            Where checklist.status=1;

    END IF; 

    IF (_Action='SelectById') THEN 
            SELECT checklist.*,affectationMission.status AS Check_AfMi,membre.nom AS Check_Membre
            			FROM checklist
    		INNER JOIN affectationMission ON affectationMission.affectationMissionId = checklist.affectationMissionId
			INNER JOIN membre ON membre.membreId = checklist.membreId
                    WHERE checklist.checklistId = _checklistId and checklist.status=1=1; 

    END IF; 

 
 

     

END;

