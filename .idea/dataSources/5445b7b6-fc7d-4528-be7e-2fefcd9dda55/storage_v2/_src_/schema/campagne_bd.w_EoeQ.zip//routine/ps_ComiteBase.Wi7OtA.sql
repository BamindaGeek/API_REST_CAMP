create
    definer = root@localhost procedure ps_ComiteBase(IN _comiteBaseId varchar(36), IN _libelle varchar(255),
                                                     IN _code varchar(36), IN _sectionId varchar(36), IN _status int(2),
                                                     IN _createdBy varchar(36), IN _action varchar(100))
BEGIN 

    #Routine body goes here... 

    IF (_action='Insert') THEN 

        INSERT INTO comitebase (comiteBaseId, libelle, code, sectionId,status,  createdBy) 

        VALUES (_comiteBaseId, _libelle, _code, _sectionId,_status, _createdBy); 

    END IF; 

    IF (_action='UpdateById') THEN 

        UPDATE comitebase 

        SET  

            comiteBaseId = _comiteBaseId, 

            libelle = _libelle, 
            
            code = _code,
            
            sectionId = _sectionId

        WHERE comiteBaseId = _comiteBaseId; 

    END IF; 

    IF (_Action='DeleteById') THEN 

            UPDATE comitebase 

            SET 

                status = 0  

            WHERE   comiteBaseId = _comiteBaseId ; 

        END IF; 

 
 

        IF (_Action='SelectAll') THEN 

            SELECT comitebase.*, s.libelle as LibelleSection
            FROM comitebase 
                    INNER JOIN section s on comitebase.sectionId = s.sectionId
            WHERE comitebase.status = 1; 

    END IF; 

    IF (_Action='SelectById') THEN

        SELECT c.*,
              (SELECT CONCAT(m.nom , ' ', m.prenom)  as Coordinateur FROM affectation a INNER JOIN membre m on a.acteurId = m.membreId where a.blocId=c.comiteBaseId AND a.status=1) as Coordinateur,
               (SELECT m2.contact FROM affectation a INNER JOIN membre m2 on a.acteurId = m2.membreId where a.blocId=c.comiteBaseId  AND a.status=1) as contact
        FROM comitebase c
                 INNER JOIN section s2 on c.sectionId = s2.sectionId
                    WHERE s2.sectionId = _comiteBaseId and c.status=1; 

    END IF; 
     
END;

