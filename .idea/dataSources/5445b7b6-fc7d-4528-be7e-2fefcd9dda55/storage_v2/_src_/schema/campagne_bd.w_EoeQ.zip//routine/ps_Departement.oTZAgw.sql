create
    definer = root@localhost procedure ps_Departement(IN _departementId varchar(36), IN _libelle varchar(255),
                                                      IN _regionId varchar(255), IN _status int(2),
                                                      IN _createdBy varchar(36), IN _action varchar(100))
BEGIN

    #Routine body goes here...

    IF (_action='Insert') THEN

        INSERT INTO departement (departementId, libelle, regionId,status, createdBy)

        VALUES (_departementId, _libelle,_regionId,_status, _createdBy);

    END IF;

    IF (_action='UpdateById') THEN

        UPDATE departement

        SET

            departementId = _departementId,

            libelle = _libelle,

            regionId = _regionId

        WHERE departementId = _departementId;

    END IF;

    IF (_Action='DeleteById') THEN

        UPDATE departement

        SET

            status=0

        WHERE   departementId =_departementId ;

    END IF;




    IF (_Action='SelectAll') THEN

        SELECT * FROM departement
        Where status=1  ORDER BY libelle ASC;

    END IF;


    IF (_Action='SelectById') THEN

        SELECT departement.*
        FROM departement
        WHERE departement.regionId = _regionId and status=1;

    END IF;
END;

