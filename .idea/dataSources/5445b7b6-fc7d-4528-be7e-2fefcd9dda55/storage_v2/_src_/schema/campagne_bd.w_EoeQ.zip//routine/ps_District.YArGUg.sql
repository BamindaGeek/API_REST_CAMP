create
    definer = root@localhost procedure ps_District(IN _districtId varchar(36), IN _libelle varchar(255),
                                                   IN _status int(2), IN _createdBy varchar(36),
                                                   IN _action varchar(100))
BEGIN

    #Routine body goes here...

    IF (_action='Insert') THEN

        INSERT INTO district (districtId, libelle,status, createdBy)

        VALUES (_districtId, _libelle,_status, _createdBy);

    END IF;

    IF (_action='UpdateById') THEN

        UPDATE district

        SET
            libelle = _libelle

        WHERE districtId = _districtId;

    END IF;

    IF (_Action='DeleteById') THEN

        UPDATE district

        SET

            status=0

        WHERE   districtId = _districtId;

    END IF;




    IF (_Action='SelectAll') THEN

        SELECT * FROM district
        Where status=1 ORDER BY libelle ASC;

    END IF;




    IF (_Action='SelectById') THEN

        SELECT * FROM district

        WHERE districtId = _districtId and status=1;

    END IF;
END;

