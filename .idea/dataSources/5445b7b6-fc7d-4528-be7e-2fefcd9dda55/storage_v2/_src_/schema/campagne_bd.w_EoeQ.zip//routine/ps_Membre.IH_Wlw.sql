create
    definer = root@localhost procedure ps_Membre(IN _membreId varchar(36), IN _numeroElecteur varchar(36),
                                                 IN _numeroCNI varchar(36), IN _nom varchar(100),
                                                 IN _prenom varchar(100), IN _email varchar(100),
                                                 IN _contact varchar(36), IN _sex char(10), IN _communeId varchar(36),
                                                 IN _comiteBaseId varchar(36), IN _lieuVoteId varchar(36),
                                                 IN _dateNaissance varchar(15), IN _lieuNaissance varchar(36),
                                                 IN _adressePhysique varchar(255), IN _adressePostale varchar(255),
                                                 IN _profession varchar(255), IN _nomPere varchar(255),
                                                 IN _prenomPere varchar(255), IN _dateNaissancePere varchar(15),
                                                 IN _lieuNaissancePere varchar(255), IN _nomMere varchar(255),
                                                 IN _prenomMere varchar(255), IN _dateNaissanceMere varchar(15),
                                                 IN _lieuNaissanceMere varchar(255), IN _status int(2),
                                                 IN _createdBy varchar(36), IN _action varchar(36))
BEGIN 

    #Routine body goes here... 

    IF (_action='Insert') THEN 

        INSERT INTO membre (membreId,numeroElecteur,numeroCNI,nom,prenom,email,contact,sex,communeId,lieuVoteId,typeMembreId, dateNaissance,lieuNaissance,adressePhysique,adressePostale,profession,nomPere,prenomPere,dateNaissancePere,lieuNaissancePere, nomMere,prenomMere,dateNaissanceMere,lieuNaissanceMere,status,createdBy)

        VALUES (_membreId,_numeroElecteur,_numeroCNI,_nom,_prenom,_email,_contact,_sex,_communeId,_lieuVoteId,(SELECT tm.typeMembreId FROM typemembre tm WHERE tm.libelle='Militant'), _dateNaissance,_lieuNaissance,_adressePhysique,_adressePostale,profession,_nomPere,_prenomPere,_dateNaissancePere,_lieuNaissancePere,_nomMere,_prenomMere,_dateNaissanceMere,_lieuNaissanceMere,_status,_createdBy); 
        
        CALL ps_AffectationMembre(UUID(),_membreId,_comiteBaseId,_status,_createdBy,_action);
        
    END IF; 

    IF (_action='UpdateById') THEN 

        UPDATE membre 

        SET   
            numeroElecteur=_numeroElecteur,
            numeroCNI = _numeroCNI,
            nom = _nom, 
            prenom =  _nom ,          
            email = _email,
            contact = _contact,
            sex = _sex,
            communeId = _communeId,
            lieuVoteId = _lieuVoteId,
            dateNaissance = _dateNaissance,
            lieuNaissance = _lieuNaissance,
            adressePhysique = _adressePhysique,
            adressePostale = _adressePostale,
            profession = _profession,
            nomPere = _nomPere,
            prenomPere = _prenomPere,
            dateNaissancePere = _dateNaissancePere,
            lieuNaissancePere = _dateNaissancePere,
            nomMere = _nomMere,
            prenomMere = _prenomMere,
            dateNaissanceMere = _dateNaissanceMere,
            lieuNaissanceMere = _dateNaissanceMere

        WHERE membreId = _membreId; 

    END IF; 

    IF (_action='DeleteById') THEN 

            UPDATE membre 

            SET 

                status = 0  

            WHERE   membreId = _membreId ; 

        END IF; 

 
 

        IF (_action='SelectAll') THEN 

            SELECT membre.*, s.libelle AS libelleCommune
            FROM membre 
            INNER JOIN sousprefecture s on membre.communeId = s.sousPrefectureId
            WHERE membre.status=1 LIMIT 1000; 

    END IF;

    IF (_action='SelectAllBy') THEN

        SELECT membre.*, (SELECT count(af.affectationId) FROM affectation af WHERE af.blocId=c.comiteBaseId AND af.type = 5 AND af.status=1) AS AnimateurActif,
               (SELECT count(af.affectationId) FROM affectation af WHERE af.acteurId=membre.membreId AND af.type = 5 AND af.status=1) AS AnimateurStatut,
               (SELECT af.affectationId FROM affectation af WHERE af.acteurId=membre.membreId AND af.type = 5 AND af.status=1) AS affectationId
        FROM membre
                 INNER JOIN affectationmembre a on membre.membreId = a.membreId
                 INNER JOIN comitebase c on a.comiteBaseId = c.comiteBaseId
        WHERE c.comiteBaseId = _membreId AND membre.status=1;

    END IF;


    IF (_action='SelectById') THEN

        SELECT membre.*, s.libelle AS libelleCommune
        FROM membre
                 INNER JOIN sousprefecture s on membre.communeId = s.sousPrefectureId
            WHERE membre.membreId = _membreId AND membre.status=1; 

    END IF;
    
    IF (_action='Filtre') THEN

        SELECT membre.*,(SELECT count(af.affectationId) FROM affectation af WHERE af.blocId=s2.sectionId AND af.type = 4 AND af.status=1) AS CoordinateurActif,
               (SELECT count(af.affectationId) FROM affectation af WHERE af.acteurId=membre.membreId AND af.type = 4 AND af.status=1) AS CoordinateurStatut,
               (SELECT af.affectationId FROM affectation af WHERE af.acteurId=membre.membreId AND af.type = 4 AND af.status=1) AS affectationId,
               (SELECT count(af.affectationId) FROM affectation af WHERE af.acteurId=membre.membreId AND af.type = 5 AND af.status=1) AS AnimateurStatut
        FROM membre
                 INNER JOIN affectationmembre a on membre.membreId = a.membreId
                 INNER JOIN comitebase c on a.comiteBaseId = c.comiteBaseId
                 INNER JOIN section s2 on c.sectionId = s2.sectionId
        WHERE s2.sectionId = _membreId AND membre.status=1;

    END IF;

    IF (_action='Rechercher') THEN

        SELECT el.`Numero Electeur` as numeroElecteur, el.`Nom/Nom de Jeune Fille` as nom, el.Prenoms as prenom, '' as email, '' as contact, el.Sexe as sex,
               (SELECT s.sousPrefectureId FROM sousprefecture s WHERE s.libelle = el.`Libelle Commune`) as communeId, el.`Libelle Lieu de Vote` as lieuVoteId, el.`Date de Naissance` as dateNaissance,
               el.`Lieu de Naissance` as lieuNaissance, el.`Adresse Physique` as adressePhysique, el.`Adresse Postale` as adressePostale, el.Profession as profession, el.`Nom du Pere` as nomPere,
               el.`Prenoms du Pere` as prenomPere, el.`Date de Naissance du Pere` as dateNaissancePere, el.`Lieu de Naissance du Pere` as lieuNaissancePere, el.`Nom de la Mere` as nomMere,
               el.`Prenoms de la Mere` as prenomMere, el.`Date de Naissance de la Mere` as dateNaissanceMere, el.`Lieu de Naissance de la Mere` as lieuNaissanceMere,
               (SELECT COUNT(me.membreId) FROM membre me WHERE me.numeroElecteur  =_numeroElecteur) as Nbre
        FROM electeurs2020 el
        WHERE el.`Numero Electeur` like concat('%',_numeroElecteur,'%');

    END IF;

END;

