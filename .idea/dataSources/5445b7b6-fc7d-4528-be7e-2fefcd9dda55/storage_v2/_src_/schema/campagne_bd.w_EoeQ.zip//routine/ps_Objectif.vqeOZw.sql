create
    definer = root@localhost procedure ps_Objectif(IN _objectifId varchar(36), IN _libelle varchar(255),
                                                   IN _code varchar(36), IN _valeur double, IN _communeId varchar(36),
                                                   IN _status varchar(36), IN _createdBy varchar(36),
                                                   IN _action varchar(100))
BEGIN 

    #Routine body goes here... 

    IF (_action='Insert') THEN 

        INSERT INTO objectif (objectifId, libelle, code, valeur, communeId,status, createdBy) 

        VALUES (_objectifId, _libelle, _code, _valeur, _communeId,_status, _createdBy); 

    END IF; 

    IF (_action='UpdateById') THEN 

        UPDATE objectif 

        SET  
        
            libelle = _libelle, 
            
            code = _code,
            
            valeur = _valeur,
            
            communeId = _communeId

        WHERE objectifId = _objectifId; 

    END IF; 

    IF (_action='DeleteById') THEN 

            UPDATE objectif 

            SET 

                status = 0  

            WHERE   objectifId = _objectifId ; 

        END IF; 

 
 

        IF (_Action='SelectAll') THEN 

            SELECT * FROM objectif
            
            WHERE status = 1; 

    END IF; 

 
 

    IF (_Action='SelectById') THEN 

            SELECT * FROM objectif

                    WHERE objectifId = _objectifId and status=1; 

    END IF; 
     
END;

