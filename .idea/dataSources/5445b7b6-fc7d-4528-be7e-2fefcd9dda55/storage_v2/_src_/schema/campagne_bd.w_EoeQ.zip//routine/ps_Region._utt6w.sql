create
    definer = root@localhost procedure ps_Region(IN _regionId varchar(36), IN _libelle varchar(255),
                                                 IN _districtId varchar(255), IN _status int(2),
                                                 IN _createdBy varchar(36), IN _action varchar(100))
BEGIN

    #Routine body goes here...

    IF (_action='Insert') THEN

        INSERT INTO region (regionId, libelle, districtId,status, createdBy)

        VALUES (_regionId, _libelle,_districtId,_status, _createdBy);

    END IF;

    IF (_action='UpdateById') THEN

        UPDATE region

        SET

            regionId = _regionId,

            libelle = _libelle,

            districtId = _districtId

        WHERE regionId = _regionId;

    END IF;

    IF (_Action='DeleteById') THEN

        UPDATE region

        SET

            status=0

        WHERE   regionId =_regionId ;

    END IF;




    IF (_Action='SelectAll') THEN

        SELECT * FROM region
        Where status=1  ORDER BY libelle ASC;

    END IF;


    IF (_Action='SelectById') THEN

        SELECT region.*
        FROM region
        WHERE region.districtId = _districtId and status=1;

    END IF;
END;

