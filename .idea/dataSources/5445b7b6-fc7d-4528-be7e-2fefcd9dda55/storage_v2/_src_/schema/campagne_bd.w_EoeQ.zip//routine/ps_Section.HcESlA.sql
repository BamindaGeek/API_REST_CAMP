create
    definer = root@localhost procedure ps_Section(IN _sectionId varchar(36), IN _libelle varchar(255),
                                                  IN _code varchar(36), IN _communeId varchar(36), IN _status int(2),
                                                  IN _createdBy varchar(36), IN _action varchar(100))
BEGIN 

    #Routine body goes here... 

    IF (_action='Insert') THEN 

        INSERT INTO section (sectionId, libelle,code,communeId,createdBy) 

        VALUES (_sectionId, _libelle,_code, _communeId, _createdBy); 

    END IF; 

    IF (_action='UpdateById') THEN 

        UPDATE section 

        SET  

            sectionId = _sectionId, 

            libelle = _libelle,

            code=_code,

            communeId=_communeId

        WHERE sectionId=_sectionId; 

    END IF; 

    IF (_Action='DeleteById') THEN 

            UPDATE section 

            SET 

                status=0  

            WHERE   sectionId =_sectionId ; 

        END IF; 

 
 

        IF (_Action='SelectAll') THEN 

            SELECT section.*,s.Libelle AS LibelleCommune ,(SELECT  COUNT(c.comiteBaseId) FROM  comitebase c WHERE c.sectionId=section.sectionId AND c.status=1) AS NbreCB
            FROM section
    		INNER JOIN sousprefecture s on section.communeId = s.sousPrefectureId
            Where section.status=1;

    END IF; 

 
 

    IF (_Action='SelectById') THEN

        SELECT section.*,s.Libelle AS LibelleCommune
        FROM section
                 INNER JOIN sousprefecture s on section.communeId = s.sousPrefectureId
            WHERE section.sectionId = _sectionId
				and  section.status=1; 

    END IF; 
     

END;

