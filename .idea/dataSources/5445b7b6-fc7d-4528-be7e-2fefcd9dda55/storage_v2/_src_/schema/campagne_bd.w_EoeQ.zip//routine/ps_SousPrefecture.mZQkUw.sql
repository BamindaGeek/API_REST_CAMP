create
    definer = root@localhost procedure ps_SousPrefecture(IN _sousPrefectureId varchar(36), IN _libelle varchar(255),
                                                         IN _departementId varchar(255), IN _status int(2),
                                                         IN _createdBy varchar(36), IN _action varchar(100))
BEGIN

    #Routine body goes here...

    IF (_action='Insert') THEN

        INSERT INTO sousPrefecture (sousPrefectureId, libelle, departementId,status, createdBy)

        VALUES (_sousPrefectureId, _libelle,_departementId,_status, _createdBy);

    END IF;

    IF (_action='UpdateById') THEN

        UPDATE sousPrefecture

        SET

            sousPrefectureId = _sousPrefectureId,

            libelle = _libelle,

            departementId = _departementId

        WHERE sousPrefectureId = _sousPrefectureId;

    END IF;

    IF (_Action='DeleteById') THEN

        UPDATE sousPrefecture

        SET

            status=0

        WHERE   sousPrefectureId =_sousPrefectureId ;

    END IF;




    IF (_Action='SelectAll') THEN

        SELECT * FROM sousPrefecture
        Where status=1;

    END IF;


    IF (_Action='SelectById') THEN

        SELECT sousPrefecture.*
        FROM sousPrefecture
        WHERE sousPrefecture.departementId = _departementId and status=1;

    END IF;
END;

