create procedure ps_Membre(IN `_membreId`          varchar(36), IN `_numeroElecteur` varchar(36),
                           IN `_nom`               varchar(100), IN `_prenom` varchar(100), IN `_email` varchar(100),
                           IN `_contact`           varchar(36), IN `_sex` char(10), IN `_communeId` varchar(36),
                           IN `_lieuVoteId`        varchar(36), IN `_dateNaissance` varchar(15),
                           IN `_lieuNaissance`     varchar(36), IN `_adressePhysique` varchar(255),
                           IN `_adressePostale`    varchar(255), IN `_profession` varchar(255),
                           IN `_nomPere`           varchar(255), IN `_prenomPere` varchar(255),
                           IN `_dateNaissancePere` varchar(15), IN `_lieuNaissancePere` varchar(255),
                           IN `_nomMere`           varchar(255), IN `_prenomMere` varchar(255),
                           IN `_dateNaissanceMere` varchar(15), IN `_lieuNaissanceMere` varchar(255),
                           IN `_createdBy`         varchar(36), IN `_action` varchar(36))
  BEGIN 

    #Routine body goes here... 

    IF (_action='Insert') THEN 

        INSERT INTO membre (membreId,numeroElecteur,nom,prenom,email,contact,sex,communeId,lieuVoteId, dateNaissance,lieuNaissance,adressePhysique,adressePostale,profession,nomPere,prenomPere,dateNaissancePere,lieuNaissancePere, nomMere,prenomMere,dateNaissanceMere,lieuNaissanceMere,createdBy)

        VALUES (_membreId,_numeroElecteur,_nom,_prenom,_email,_contact,_sex,_communeId,_lieuVoteId, _dateNaissance,_lieuNaissance,_adressePhysique,_adressePostale,profession,_nomPere,_prenomPere,_dateNaissancePere,_lieuNaissancePere,_nomMere,_prenomMere,_dateNaissanceMere,_lieuNaissanceMere,_createdBy); 

    END IF; 

    IF (_action='UpdateById') THEN 

        UPDATE membre 

        SET   
            numeroElecteur=_numeroElecteur,
            nom = _nom, 
            prenom =  _nom ,          
            email = _email,
            contact = _contact,
            sex = _sex,
            communeId = _communeId,
            lieuVoteId = _lieuVoteId,
            dateNaissance = _dateNaissance,
            lieuNaissance = _lieuNaissance,
            adressePhysique = _adressePhysique,
            adressePostale = _adressePostale,
            profession = _profession,
            nomPere = _nomPere,
            prenomPere = _prenomPere,
            dateNaissancePere = _dateNaissancePere,
            lieuNaissancePere = _dateNaissancePere,
            nomMere = _nomMere,
            prenomMere = _prenomMere,
            dateNaissanceMere = _dateNaissanceMere,
            lieuNaissanceMere = _dateNaissanceMere

        WHERE membreId = _membreId; 

    END IF; 

    IF (_action='DeleteById') THEN 

            UPDATE membre 

            SET 

                status = 0  

            WHERE   membreId = _membreId ; 

        END IF; 

 
 

        IF (_action='SelectAll') THEN 

            SELECT membre.*, commune.libelle AS libelleCommune, lieuvote.libelle AS libelleLieuVote 
            FROM membre 
            INNER JOIN commune ON commune.communeId = membre.communeId
            LEFT JOIN lieuvote ON lieuvote.lieuVoteId = membre.lieuVoteId
            WHERE membre.status=1; 

    END IF; 

 
 

    IF (_action='SelectById') THEN 

            SELECT membre.*, commune.libelle AS libelleCommune, lieuvote.libelle AS libelleLieuVote 
            FROM membre 
            INNER JOIN commune ON commune.communeId = membre.communeId
            LEFT JOIN lieuvote ON lieuvote.lieuVoteId = membre.lieuVoteId
            WHERE membre.membreId = _membreId AND membre.status=1; 

    END IF; 

END;

