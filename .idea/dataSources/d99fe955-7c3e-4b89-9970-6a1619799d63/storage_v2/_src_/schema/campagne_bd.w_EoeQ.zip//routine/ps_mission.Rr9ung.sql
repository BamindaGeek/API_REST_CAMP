create procedure ps_Mission(IN `_missionId` varchar(36), IN `_libelle` varchar(255), IN `_checkList` int(2),
                            IN `_createdBy` varchar(36), IN `_action` varchar(100))
  BEGIN 

    #Routine body goes here... 

    IF (_action='Insert') THEN 

        INSERT INTO mission (missionId, libelle, checkList, createdBy) 

        VALUES (_missionId, _libelle,_checklist, _createdBy); 

    END IF; 

    IF (_action='UpdateById') THEN 

        UPDATE mission 

        SET  

            missionId = _missionId, 

            libelle = _libelle,

            checkList = _checkList

        WHERE missionId = _missionId; 

    END IF; 

    IF (_Action='DeleteById') THEN 

            UPDATE mission 

            SET 

                status=0  

            WHERE   missionId =_missionId ; 

        END IF; 

 
 

        IF (_Action='SelectAll') THEN 

            SELECT * FROM mission
            Where status=1; 

    END IF; 

 
 

    IF (_Action='SelectById') THEN 

            SELECT * FROM mission 

                    WHERE mission.missionId = _missionId and status=1; 

    END IF; 
END;

