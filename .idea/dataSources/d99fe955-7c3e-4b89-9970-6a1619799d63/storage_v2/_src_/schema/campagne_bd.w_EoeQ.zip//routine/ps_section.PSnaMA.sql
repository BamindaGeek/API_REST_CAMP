create procedure ps_Section(IN `_sectionId`    varchar(36), IN `_libelle` varchar(255), IN `_code` varchar(36),
                            IN `_comiteBaseId` varchar(36), IN `_status` int(2), IN `_createdBy` varchar(36),
                            IN `_action`       varchar(100))
  BEGIN 

    #Routine body goes here... 

    IF (_action='Insert') THEN 

        INSERT INTO section (sectionId, libelle,code,comiteBaseId,createdBy) 

        VALUES (_sectionId, _libelle,_code, _comiteBaseId, _createdBy); 

    END IF; 

    IF (_action='UpdateById') THEN 

        UPDATE section 

        SET  

            sectionId = _sectionId, 

            libelle = _libelle,

            code=_code,

            comiteBaseId=_comiteBaseId

        WHERE sectionId=_sectionId; 

    END IF; 

    IF (_Action='DeleteById') THEN 

            UPDATE section 

            SET 

                status=0  

            WHERE   sectionId =_sectionId ; 

        END IF; 

 
 

        IF (_Action='SelectAll') THEN 

            SELECT section.*,comiteBase.Libelle AS Sec_Com
            FROM section
    		INNER JOIN comiteBase ON comiteBase.comiteBaseId = section.comiteBaseId
            Where section.status=1;

    END IF; 

 
 

    IF (_Action='SelectById') THEN 

            SELECT section.*, comiteBase.Libelle AS Sec_Com 
            FROM section
            INNER JOIN comiteBase ON comiteBase.comiteBaseId = section.comiteBaseId
            WHERE section.sectionId = _sectionId
				and  section.status=1; 

    END IF; 
     

END;

