create procedure ps_TypeMembre(IN `_typeMembreId` varchar(36), IN `_libelle` varchar(255), IN `_code` varchar(36),
                               IN `_status`       int(2), IN `_createdBy` varchar(36), IN `_action` varchar(100))
  BEGIN 

    #Routine body goes here... 

    IF (_action='Insert') THEN 

        INSERT INTO typeMembre (typeMembreId, libelle,code, status, createdBy) 

        VALUES (_typeMembreId, _libelle,_code, _status, _createdBy); 

    END IF; 

    IF (_action='UpdateById') THEN 

        UPDATE typeMembre 

        SET  

            typeMembreId = _typeMembreId, 

            libelle = _libelle,

            code=_code, 

            status = _status

        WHERE typeMembreId=_typeMembreId; 

    END IF; 

    IF (_Action='DeleteById') THEN 

            UPDATE typeMembre 

            SET 

                status=0  

            WHERE   typeMembreId =_typeMembreId ; 

        END IF; 

 
 

        IF (_Action='SelectAll') THEN 

            SELECT * FROM typeMembre
            where status = 1; 

    END IF; 

 
 

    IF (_Action='SelectById') THEN 

            SELECT * FROM typeMembre 

                    WHERE typeMembre.typeMembreId = _typeMembreId and status=1; 

    END IF; 

END;

