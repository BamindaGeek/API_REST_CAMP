create
    definer = root@localhost procedure ps_Access(IN _pseudo varchar(100), IN _password varchar(255),
                                                 IN _expiredOn timestamp, IN _membreId varchar(36), IN _status int(2),
                                                 IN _action varchar(100))
BEGIN 
	DECLARE membreId VARCHAR(36);	
	IF (_action='Insert') THEN
		INSERT INTO access ( accessId, pseudo, password, createdOn, expiredOn, membreId, status)
		VALUE (_accessId, _pseudo, _password, NOW(), _expiredOn,_membreId, _status);
	END IF;

	IF (_action='UpdateById') THEN
		UPDATE  access
		SET
			password = _password,
			pseudo = _pseudo,
			expiredOn =_expiredOn,
			status = _statut
		WHERE   accessId = _accessId ;
	END IF;

	IF (_action='DeleteById') THEN
		UPDATE  access
		SET status = 0 
		WHERE   accessId = _accessId ;     
	END IF;
	IF (_action='SelectAll') THEN
		SELECT m.*, a.accessId,a.expiredOn, a.password, a.pseudo, a.status as etatAccess
		FROM access a 
		INNER JOIN membre m ON m.membreId = a.membreId 
		WHERE a.status = 1;     
	END IF;
	IF (_action='Connect') THEN
		SET membreId = (SELECT a.membreId 
		FROM access a
		INNER JOIN membre m ON m.membreId = a.PersonneId
		WHERE a.status =_status AND password = _password AND (pseudo = _pseudo OR phone = _pseudo OR email = _pseudo));
		IF membreId IS NOT NULL 
		THEN
		SELECT m.*, a.password, a.pseudo, a.accessId, a.status as etatAccess
		FROM access a
		INNER JOIN membre m ON m.membreId = a.membreId
		WHERE m.membreId = membreId;
	ELSE
		SELECT 1;
	END IF;
	END IF;
END;

