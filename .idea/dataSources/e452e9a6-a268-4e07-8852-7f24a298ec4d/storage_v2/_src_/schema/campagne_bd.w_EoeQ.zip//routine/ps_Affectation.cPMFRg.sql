create
    definer = root@localhost procedure ps_Affectation(IN _affectationId varchar(36), IN _acteurId varchar(36),
                                                      IN _blocId varchar(36), IN _type int(2),
                                                      IN _createdBy varchar(36), IN _action varchar(100))
BEGIN
	#Routine body goes here...
	IF (_action='Insert') THEN
		INSERT INTO affectation (affectationId, acteurId, blocId, type, createdBy)
		VALUES (_affectationId, _acteurId, _blocId, _type, _createdBy);
	END IF;
	IF (_action='UpdateById') THEN
		UPDATE affectation
		SET 
			affectationId = _affectationId,
			acteurId = _acteurId,
			blocId = _blocId,
			type = _type
		WHERE affectationId=_affectationId;
	END IF;
    IF (_Action='Delete') THEN
			UPDATE affectation
			SET
				status=0 
			WHERE   affectationId =_affectationId ;     
		END IF;
	IF ((_action='SelectAll') AND (_type=1)) THEN
			SELECT a.*, m.nom, m.prenom, c.libelle
			FROM affectation a
			INNER JOIN commitebase c ON a.blocId = c.comiteBaseId
			INNER JOIN membre m  ON m.membreId = a.acteurId
            WHERE a.status=1;
	END IF;
    IF ((_action='SelectAll') AND (_type=2)) THEN
			SELECT a.*, m.nom, m.prenom, s.libelle
			FROM affectation a
			INNER JOIN section s ON a.blocId = s.comiteBaseId
			INNER JOIN membre m  ON m.membreId = a.acteurId
            WHERE a.status=1;
	END IF;
	IF ((_action='SelectById' AND (_type=1))) THEN
			SELECT a.*, m.nom, m.prenom, c.libelle
			FROM affectation a
			INNER JOIN commitebase c ON a.blocId = c.comiteBaseId
			INNER JOIN membre m  ON m.membreId = a.acteurId
            WHERE a.affectationId = _affectationID AND a.status=1;
	END IF;
    IF ((_action='SelectById' AND (_type=2))) THEN
			SELECT a.*, m.nom, m.prenom, s.libelle
			FROM affectation a
			INNER JOIN section s ON a.blocId = s.comiteBaseId
			INNER JOIN membre m  ON m.membreId = a.acteurId
            WHERE a.affectationId = _affectationID AND a.status=1;
	END IF;
END;

