create
    definer = root@localhost procedure ps_ComiteBase(IN _comiteBaseId varchar(36), IN _libelle varchar(255),
                                                     IN _code int, IN _createdBy int)
BEGIN 

    #Routine body goes here... 

    IF (_action='Insert') THEN 

        INSERT INTO comitebase (comiteBaseId, libelle, code, status, createdBy) 

        VALUES (_comiteBaseId, _libelle, _code, _status, _createdBy); 

    END IF; 

    IF (_action='UpdateById') THEN 

        UPDATE comitebase 

        SET  

            comiteBaseId = _comiteBaseId, 

            libelle = _libelle, 
            
            code = _code,

            status = _status

        WHERE comiteBaseId = _comiteBaseId; 

    END IF; 

    IF (_Action='Delete') THEN 

            UPDATE comitebase 

            SET 

                status = 0  

            WHERE   comiteBaseId = _comiteBaseId ; 

        END IF; 

 
 

        IF (_Action='SelectAll') THEN 

            SELECT * FROM comitebase
            
            WHERE status = 1; 

    END IF; 

 
 

    IF (_Action='SelectById') THEN 

            SELECT * FROM comitebase

                    WHERE comiteBaseId = _comiteBaseId and status=1; 

    END IF; 
     
END;

