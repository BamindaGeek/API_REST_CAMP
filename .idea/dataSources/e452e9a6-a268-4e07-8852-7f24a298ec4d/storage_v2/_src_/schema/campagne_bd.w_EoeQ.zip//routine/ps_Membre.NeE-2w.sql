create
    definer = root@localhost procedure ps_Membre(IN _membreId varchar(36), IN _nom varchar(100),
                                                 IN _prenom varchar(100), IN _email varchar(100),
                                                 IN _contact varchar(36), IN _sex char(10), IN _communeId varchar(36),
                                                 IN _lieuVoteId varchar(36), IN _dateNaissance date,
                                                 IN _lieuNaissance varchar(36), IN _adressePhysique varchar(255),
                                                 IN _adressePostale varchar(255), IN _profession varchar(255),
                                                 IN _typeMembreId varchar(36), IN _nomPere varchar(255),
                                                 IN _prenomPere varchar(255), IN _dateNaissancePere date,
                                                 IN _lieuNaissancePere varchar(255), IN _nomMere varchar(255),
                                                 IN _prenomMere varchar(255), IN _dateNaissanceMere date,
                                                 IN _lieuNaissanceMere varchar(255), IN _createdBy varchar(36))
BEGIN 

    #Routine body goes here... 

    IF (_action='Insert') THEN 

        INSERT INTO membre (membreId, libelle, status, createdBy) 

        VALUES (_campagneId, _libelle, _status, _createdBy); 

    END IF; 

    IF (_action='UpdateById') THEN 

        UPDATE campagne 

        SET  

            campagneId = _campagneId, 

            libelle = _libelle, 

            status = _status

        WHERE campagneId=_campagneId; 

    END IF; 

    IF (_Action='Delete') THEN 

            UPDATE campagne 

            SET 

                status=0  

            WHERE   campagneId =_campagneId ; 

        END IF; 

 
 

        IF (_Action='SelectAll') THEN 

            SELECT * FROM campagne_bd.campagne 
            Where status=1; 

    END IF; 

 
 

    IF (_Action='SelectById') THEN 

            SELECT * FROM campagne_bd.campagne 

                    WHERE campagne_bd.campagne.campagneId = _campagneId and status=1; 

    END IF; 

 
 

     

END;

