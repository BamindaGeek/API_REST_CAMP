create
    definer = root@localhost procedure ps_Objectif(IN _objectifId varchar(36), IN _code varchar(36),
                                                   IN _libelle varchar(255), IN _campagneId varchar(36),
                                                   IN createdBy varchar(36), IN _action varchar(100))
BEGIN 

    #Routine body goes here... 

    IF (_action='Insert') THEN 

        INSERT INTO objectif (objectifId, libelle, code, campagneId, createdBy) 

        VALUES (_objectifId, _libelle, _code, _campagneId, _createdBy); 

    END IF; 

    IF (_action='UpdateById') THEN 

        UPDATE objectif 

        SET  
        
            libelle = _libelle, 
            
            code = _code,
            
            campagneId = _campagneId

        WHERE objectifId = _objectifId; 

    END IF; 

    IF (_Action='DeleteById') THEN 

            UPDATE objectif 

            SET 

                status = 0  

            WHERE   objectifId = _objectifId ; 

        END IF; 

 
 

        IF (_Action='SelectAll') THEN 

            SELECT * FROM objectif
            
            WHERE status = 1; 

    END IF; 

 
 

    IF (_Action='SelectById') THEN 

            SELECT * FROM objectif

                    WHERE objectifId = _objectifId and status=1; 

    END IF; 
     
END;

