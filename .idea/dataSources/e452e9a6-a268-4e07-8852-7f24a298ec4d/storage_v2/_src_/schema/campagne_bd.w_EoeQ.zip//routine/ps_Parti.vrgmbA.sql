create
    definer = root@localhost procedure ps_Parti(IN _partiId varchar(36), IN _libelle int(255), IN _status int(2),
                                                IN _createdBy varchar(36), IN _action varchar(100))
BEGIN 

    #Routine body goes here... 

    IF (_action='Insert') THEN 

        INSERT INTO parti (partiId, libelle, status, createdBy) 

        VALUES (_partiId, _libelle, _status, _createdBy); 

    END IF; 

    IF (_action='UpdateById') THEN 

        UPDATE parti 

        SET  

            partiId = _partiId, 

            libelle = _libelle,

            status = _status

        WHERE partiId=_partiId; 

    END IF; 

    IF (_Action='Delete') THEN 

            UPDATE parti 

            SET 

                status=0  

            WHERE   partiId =_partiId ; 

        END IF; 

 
 

        IF (_Action='SelectAll') THEN 

            SELECT * FROM parti
            Where status=1; 

    END IF; 

 
 

    IF (_Action='SelectById') THEN 

            SELECT * FROM parti 

                    WHERE parti.partiId = _partiId and  status=1; 

    END IF; 

 
 

     

END;

