create procedure ps_Campagne(IN `_CampagneID` varchar(225), IN `_Libelle` varchar(225), IN `_Description` varchar(255),
                             IN `_Taux`       decimal, IN `_DateDebut` datetime, IN `_DateFin` datetime,
                             IN `_Action`     varchar(100))
  BEGIN
					IF (_Action = 'Insert') THEN
						INSERT INTO AutoApp.Campagne (CampagneID,Libelle, Description,Taux,DateDebut,DateFin)
							VALUES (_CampagneID,_Libelle, _Description,_Taux,_DateDebut,_DateFin);
					END IF;
				    
				    IF (_Action = 'Update') THEN
						UPDATE AutoApp.Campagne
							SET AutoApp.Campagne.Libelle = _Libelle,
							  AutoApp.Campagne.Description = _Description,
                              AutoApp.Campagne.Taux = _Taux,
                              AutoApp.Campagne.DateDebut = _DateDebut,
                              AutoApp.Campagne.DateFin = _DateFin
						WHERE AutoApp.Campagne.CampagneID = _CampagneID;
					END IF;
				    
				    IF (_Action = 'Delete') THEN
						DELETE
							FROM AutoApp.Campagne
								WHERE  AutoApp.Campagne.CampagneID = _CampagneID;
					END IF;
				END;

