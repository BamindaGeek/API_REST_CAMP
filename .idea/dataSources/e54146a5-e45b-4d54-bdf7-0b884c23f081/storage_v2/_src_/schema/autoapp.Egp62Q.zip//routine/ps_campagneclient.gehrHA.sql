create procedure ps_CampagneClient(IN `_CampagneClientID` varchar(225), IN `_TypeClientID` varchar(225),
                                   IN `_CampagneID`       varchar(255), IN `_Action` varchar(100))
  BEGIN
					IF (_Action = 'Insert') THEN
						INSERT INTO AutoApp.CampagneClient (CampagneClientID,TypeClientID, CampagneID)
							VALUES (_CampagneClientID,_TypeClientID, _CampagneID);
					END IF;
				    
				    IF (_Action = 'Update') THEN
						UPDATE AutoApp.CampagneClient
							SET AutoApp.CampagneClient.TypeClientID = _TypeClientID,
								AutoApp.CampagneClient.CampagneID = _CampaganeID
						WHERE 	AutoApp.CampagneClient.CampagneClientID = _CampaganeClientID;
                       
					END IF;
				    
				    IF (_Action = 'Delete') THEN
						DELETE
							FROM AutoApp.CampagneClient
								WHERE  AutoApp.CampagneClient.CampagneClientID = _CampagneClientID;
					END IF;
				END;

