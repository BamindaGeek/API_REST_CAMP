create procedure ps_Client(IN `_ClientID`     varchar(255), IN `_Nom` varchar(255), IN `_Prenom` varchar(255),
                           IN `_Contact`      varchar(255), IN `_Email` varchar(255), IN `_Photo` varchar(255),
                           IN `_TypeClientID` varchar(255), IN `_Action` varchar(100))
  BEGIN
					IF (_Action = 'Insert') THEN
						INSERT INTO AutoApp.Client (ClientID,Nom, Prenom, Contact, Email, Photo, TypeClientID)
							VALUES (_ClientID,_Nom, _Prenom, _Contact, _Email, _Photo, _TypeClientID );
					END IF;
				    
				    IF (_Action = 'Update') THEN
						UPDATE AutoApp.Client
							SET AutoApp.Client.Nom = _Nom,
							    AutoApp.Client.Prenom = _Prenom,
							    AutoApp.Client.Contact = _Contact,
							    AutoApp.Client.Email = _Email,
							    AutoApp.Client.Photo = _Photo,
							    AutoApp.Client.TypeClientID = _TypeClientID								
							WHERE AutoApp.Client.ClientID = _ClientID;
					END IF;
				    
				    IF (_Action = 'Delete') THEN
						DELETE
							FROM AutoApp.Client
								WHERE  AutoApp.Client.ClientID = _ClientID;
					END IF;
				END;

