create procedure ps_Critere(IN `_CritereID` varchar(255), IN `_Libelle` varchar(255), IN `_Description` varchar(255),
                            IN `_Nbre`      int, IN `_Montant` decimal, IN `_Action` varchar(100))
  BEGIN
					IF (_Action = 'Insert') THEN
						INSERT INTO AutoApp.Critere (CritereID,Libelle, Description, Nbre, Montant)
							VALUES (_CritereID,_Libelle,_Description,_Nbre,_Montant);
					END IF;
				    
				    IF (_Action = 'Update') THEN
						UPDATE AutoApp.Critere
							SET AutoApp.Critere.Libelle = _Libelle,
							    AutoApp.Critere.Description = _Description,
                                AutoApp.Critere.Nbre = _Nbre,						
								AutoApp.Critere.Montant = _Montant
                               WHERE AutoApp.Critere.CritereID = _CritereID;
					END IF;
				    
				    IF (_Action = 'Delete') THEN
						DELETE
							FROM AutoApp.Critere
								WHERE  AutoApp.Critere.CritereID = _CritereID;
					END IF;
				END;

