create procedure ps_Location(IN `_LocationID`  varchar(225), IN `_DateDebut` datetime, IN `_DateFin` datetime,
                             IN `_ChauffeurID` varchar(225), IN `_Action` varchar(100))
  BEGIN
					IF (_Action = 'Insert') THEN
						INSERT INTO AutoApp.Location (LocationID,DateDebut,DateFin,ChauffeurID)
							VALUES (_LocationID,_DateDebut,_DateFin,_ChauffeurID);
					END IF;
				    
				    IF (_Action = 'Update') THEN
						UPDATE AutoApp.Campagne
                              set AutoApp.Location.DateDebut = _DateDebut,
                              AutoApp.Location.DateFin = _DateFin,
                              AutoApp.Location.ChauffeurID = _ChauffeurID
						WHERE AutoApp.Location.LocationID = _LocationID;
					END IF;
				    
				    IF (_Action = 'Delete') THEN
						DELETE
							FROM AutoApp.Location
								WHERE  AutoApp.Location.LocationID = _LocationID;
					END IF;
				END;

