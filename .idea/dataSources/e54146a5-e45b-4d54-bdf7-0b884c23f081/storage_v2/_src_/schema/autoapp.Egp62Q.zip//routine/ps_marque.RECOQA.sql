create procedure ps_Marque(IN `_Libelle` varchar(255), IN `_Description` varchar(225), IN `_Action` varchar(100))
  BEGIN
					IF (_Action = 'Insert') THEN
						INSERT INTO AutoApp.Marque (Libelle, Description)
							VALUES (_Libelle, _Description);
					END IF;
				    
				    IF (_Action = 'Update') THEN
						UPDATE AutoApp.Marque
							SET AutoApp.Marque.Description = _Description
							WHERE AutoApp.Marque.Libelle = _Libelle;
					END IF;
				    
				    IF (_Action = 'Delete') THEN
						DELETE
							FROM AutoApp.Marque
								WHERE  AutoApp.Marque.Libelle = _Libelle;
					END IF;
				END;

