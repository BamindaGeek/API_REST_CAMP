create procedure ps_Modele(IN `_TypeModeleID`   varchar(255), IN `_Description` varchar(255),
                           IN `_TypeVehiculeID` varchar(255), IN `_MarqueID` varchar(255), IN `_Action` varchar(100))
  BEGIN
					IF (_Action = 'Insert') THEN
						INSERT INTO AutoApp.Modele (ModeleID,Description, TypeVehiculeID, MarqueID)
							VALUES (_ModeleID,_Description,_TypeVehiculeID,_MarqueID);
					END IF;
				    
				    IF (_Action = 'Update') THEN
						UPDATE AutoApp.Modele
							SET AutoApp.Modele.Description = _Description,
                                AutoApp.Modele.TypeVehiculeID = _TypeVehiculeID	,
                                AutoApp.Modele.MarqueID = _MarqueID	
							WHERE AutoApp.Modele.ModeleID = _Modele;
					END IF;
				    
				    IF (_Action = 'Delete') THEN
						DELETE
							FROM AutoApp.Modele
								WHERE  AutoApp.Modele.ModeleID = _ModeleID;
					END IF;
				END;

