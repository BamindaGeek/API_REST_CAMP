create procedure ps_Paiement(IN `_PaiementID`     varchar(255), IN `_Date` datetime, IN `_Montant` decimal,
                             IN `_STATUT`         varchar(255), IN `_Description` varchar(255),
                             IN `_TransactionsID` varchar(225), IN `_Action` varchar(100))
  BEGIN
					IF (_Action = 'Insert') THEN
						INSERT INTO AutoApp.Paiement (PaiementID,Date,Montant,STATUT,TransactionsID)
							VALUES (_PaiementID,_Date,_Montant,_STATUT,Description,_TransactionsID);
					END IF;
				    
				    IF (_Action = 'Update') THEN
						UPDATE AutoApp.Paiement
							SET AutoApp.Paiement.Date= _Date,
								AutoApp.Paiement.Montant = _Montant,
                                AutoApp.Paiement.STATUT = _STATUT,
                                AutoApp.Paiement.Description = _Description,
                                AutoApp.Paiement.TransactionsID = _TransactionsID
                           WHERE AutoApp.Paiement.PaiementID = _PaiementID;
					END IF;
				    
				    IF (_Action = 'Delete') THEN
						DELETE
							FROM AutoApp.Paiement
								WHERE  AutoApp.Paiement.PaiementID = _PaiementID;
					END IF;
				END;

