create procedure ps_Panne(IN `_PanneID` varchar(255), IN `_Libelle` varchar(225), IN `_Description` varchar(225),
                          IN `_Action`  varchar(100))
  BEGIN
					IF (_Action = 'Insert') THEN
						INSERT INTO AutoApp.Panne (PanneID,Libelle,Description)
							VALUES (_PanneID,_Libelle, _Description);
					END IF;
				    
				    IF (_Action = 'Update') THEN
						UPDATE AutoApp.Panne
							SET AutoApp.Panne.Libelle = _Libelle,
								AutoApp.Panne.Description = _Description
							WHERE AutoApp.Panne.PanneID = _PanneID;
					END IF;
				    
				    IF (_Action = 'Delete') THEN
						DELETE
							FROM AutoApp.Panne
								WHERE  AutoApp.Panne.PanneID = _PanneID;
					END IF;
				END;

