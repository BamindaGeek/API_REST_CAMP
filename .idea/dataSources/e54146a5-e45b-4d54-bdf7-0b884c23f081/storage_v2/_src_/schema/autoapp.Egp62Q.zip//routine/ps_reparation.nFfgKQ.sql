create procedure ps_Reparation(IN `_ReparationID`  varchar(255), IN `_Date` datetime, IN `_Montant` int,
                               IN `_VehiculeID`    varchar(255), IN `_PanneID` varchar(255),
                               IN `_FournisseurID` varchar(255), IN `_Action` varchar(100))
  BEGIN
					IF (_Action = 'Insert') THEN
						INSERT INTO AutoApp.Reparation (ReparationID,Date,Montant,VehiculeID,PanneID,FournisseurID)
							VALUES (_ReparationID,_Date,_Montant,_VehiculeID,_PanneID,_FournisseurID);
					END IF;
				    
				    IF (_Action = 'Update') THEN
						UPDATE AutoApp.Reparation
							SET AutoApp.Reparation.Date = _Date,
								AutoApp.Reparation.Montant = _Montant,
								AutoApp.Reparation.VehiculeID = _VehiculeID,
                                AutoApp.Reparation.PanneID = _PanneID,
                                AutoApp.Reparation.FournisseurID = _FournisseurID
                         WHERE    AutoApp.Reparation.ReparationID = _ReparationID;
								
					END IF;
				    
				    IF (_Action = 'Delete') THEN
						DELETE
							FROM AutoApp.Reparation
								WHERE  AutoApp.Reparation.ReparationID = _ReparationID;
					END IF;
				END;

