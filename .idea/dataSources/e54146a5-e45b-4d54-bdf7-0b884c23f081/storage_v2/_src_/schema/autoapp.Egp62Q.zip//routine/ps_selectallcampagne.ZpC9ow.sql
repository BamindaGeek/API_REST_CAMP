create procedure ps_SelectAllCampagne()
  BEGIN
				SELECT * FROM AutoApp.Campagne;
			END;

