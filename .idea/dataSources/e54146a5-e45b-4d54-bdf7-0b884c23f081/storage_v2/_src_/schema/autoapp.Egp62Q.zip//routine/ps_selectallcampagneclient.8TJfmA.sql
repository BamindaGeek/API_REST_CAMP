create procedure ps_SelectAllCampagneClient()
  BEGIN
				SELECT * FROM AutoApp.CampagneClient;
			END;

