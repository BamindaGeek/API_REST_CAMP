create procedure ps_SelectAllChauffeur()
  BEGIN
				SELECT * FROM AutoApp.Chauffeur;
			END;

