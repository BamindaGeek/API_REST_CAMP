create procedure ps_SelectAllClient()
  BEGIN
				SELECT * FROM AutoApp.Client;
			END;

