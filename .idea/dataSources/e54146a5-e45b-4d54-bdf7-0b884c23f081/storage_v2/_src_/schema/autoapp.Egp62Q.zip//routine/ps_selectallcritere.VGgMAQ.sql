create procedure ps_SelectAllCritere()
  BEGIN
				SELECT * FROM AutoApp.Critere;
			END;

