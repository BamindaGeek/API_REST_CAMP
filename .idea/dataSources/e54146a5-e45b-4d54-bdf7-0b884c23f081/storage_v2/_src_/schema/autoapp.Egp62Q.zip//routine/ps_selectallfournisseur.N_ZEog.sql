create procedure ps_SelectAllFournisseur()
  BEGIN
				SELECT * FROM AutoApp.Fournisseur;
			END;

