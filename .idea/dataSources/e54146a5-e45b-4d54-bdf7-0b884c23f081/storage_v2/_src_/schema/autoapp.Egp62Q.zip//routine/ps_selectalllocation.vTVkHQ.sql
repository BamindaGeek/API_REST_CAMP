create procedure ps_SelectAllLocation()
  BEGIN
				SELECT * FROM AutoApp.Location;
			END;

