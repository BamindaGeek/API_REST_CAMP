create procedure ps_SelectAllMarque()
  BEGIN
				SELECT * FROM AutoApp.Marque;
			END;

