create procedure ps_SelectAllModele()
  BEGIN
				SELECT * FROM AutoApp.Modele;
			END;

