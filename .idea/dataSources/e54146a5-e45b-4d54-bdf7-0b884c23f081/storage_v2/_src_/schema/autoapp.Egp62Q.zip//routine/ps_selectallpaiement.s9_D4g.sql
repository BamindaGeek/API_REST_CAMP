create procedure ps_SelectAllPaiement()
  BEGIN
				SELECT * FROM AutoApp.Paiement;
			END;

