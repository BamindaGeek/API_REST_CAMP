create procedure ps_SelectAllPanne()
  BEGIN
				SELECT * FROM AutoApp.Panne;
			END;

