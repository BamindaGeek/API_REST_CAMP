create procedure ps_SelectAllReparation()
  BEGIN
				SELECT * FROM AutoApp.Reparation;
			END;

