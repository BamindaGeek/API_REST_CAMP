create procedure ps_SelectAllTransactions()
  BEGIN
				SELECT * FROM AutoApp.Transactions;
			END;

