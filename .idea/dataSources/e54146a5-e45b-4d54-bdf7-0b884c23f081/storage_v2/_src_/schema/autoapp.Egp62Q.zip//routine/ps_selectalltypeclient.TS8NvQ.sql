create procedure ps_SelectAllTypeClient()
  BEGIN
				SELECT * FROM AutoApp.TypeClient;
			END;

