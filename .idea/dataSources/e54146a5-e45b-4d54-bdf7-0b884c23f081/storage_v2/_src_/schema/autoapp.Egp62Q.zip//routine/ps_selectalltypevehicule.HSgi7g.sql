create procedure ps_SelectAllTypeVehicule()
  BEGIN
				SELECT * FROM AutoApp.TypeVehicule;
			END;

