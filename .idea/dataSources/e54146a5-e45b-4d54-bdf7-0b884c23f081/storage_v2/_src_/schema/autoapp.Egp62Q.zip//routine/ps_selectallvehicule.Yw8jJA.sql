create procedure ps_SelectAllVehicule()
  BEGIN
				SELECT * FROM AutoApp.Vehicule;
			END;

