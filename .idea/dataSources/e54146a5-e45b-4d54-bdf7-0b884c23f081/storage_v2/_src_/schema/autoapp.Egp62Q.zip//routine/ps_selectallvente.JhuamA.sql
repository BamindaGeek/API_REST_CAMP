create procedure ps_SelectAllVente()
  BEGIN
				SELECT * FROM AutoApp.Vente;
			END;

