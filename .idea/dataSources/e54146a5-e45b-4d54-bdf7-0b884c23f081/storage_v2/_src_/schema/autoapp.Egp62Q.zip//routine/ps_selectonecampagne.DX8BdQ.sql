create procedure ps_SelectOneCampagne(IN `_CampagneID` varchar(255))
  BEGIN
				SELECT * FROM AutoApp.Campagne
					WHERE AutoApp.Campagne.CampagneID = _CampagneID;
		END;

