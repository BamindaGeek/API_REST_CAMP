create procedure ps_SelectOneCampagneClient(IN `_CampagneClientID` varchar(255))
  BEGIN
				SELECT * FROM AutoApp.CampagneClient
					WHERE AutoApp.CampagneClient.CampagneClientID = _CampagneClientID;
		END;

