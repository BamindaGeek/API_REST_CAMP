create procedure ps_SelectOneChauffeur(IN `_ChauffeurID` varchar(255))
  BEGIN
				SELECT * FROM AutoApp.Chauffeur
					WHERE AutoApp.Chauffeur.ChauffeurID = _ChauffeurID;
		END;

