create procedure ps_SelectOneClient(IN `_ClientID` varchar(255))
  BEGIN
				SELECT * FROM AutoApp.Client
					WHERE AutoApp.Client.ClientID = _ClientID;
		END;

