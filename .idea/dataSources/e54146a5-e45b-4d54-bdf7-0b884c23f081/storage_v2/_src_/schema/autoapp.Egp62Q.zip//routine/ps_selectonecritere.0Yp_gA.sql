create procedure ps_SelectOneCritere(IN `_CritereID` varchar(255))
  BEGIN
				SELECT * FROM AutoApp.Critere
					WHERE AutoApp.Critere.CritereID = _CritereID;
		END;

