create procedure ps_SelectOneFournisseur(IN `_FournisseurID` varchar(255))
  BEGIN
				SELECT * FROM AutoApp.Fournisseur
					WHERE AutoApp.Fournisseur.FournisseurID = _FournisseurID;
		END;

