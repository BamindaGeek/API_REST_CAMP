create procedure ps_SelectOneLocation(IN `_LocationID` varchar(255))
  BEGIN
				SELECT * FROM AutoApp.Location
					WHERE AutoApp.Location.LocationID = _LocationID;
		END;

