create procedure ps_SelectOneMarque(IN `_Libelle` varchar(255))
  BEGIN
				SELECT * FROM AutoApp.Marque
					WHERE AutoApp.Marque.Libelle = _Libelle;
		END;

