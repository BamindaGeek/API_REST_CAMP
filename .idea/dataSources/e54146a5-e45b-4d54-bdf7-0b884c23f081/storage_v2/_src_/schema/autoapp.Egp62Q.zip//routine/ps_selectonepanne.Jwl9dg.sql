create procedure ps_SelectOnePanne(IN `_PanneID` varchar(255))
  BEGIN
				SELECT * FROM AutoApp.Panne
					WHERE AutoApp.Panne.PanneID = _PanneID;
		END;

