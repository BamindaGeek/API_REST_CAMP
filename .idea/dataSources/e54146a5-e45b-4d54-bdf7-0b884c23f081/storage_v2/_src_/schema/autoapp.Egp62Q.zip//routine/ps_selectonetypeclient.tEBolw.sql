create procedure ps_SelectOneTypeClient(IN `_TypeClientID` varchar(255))
  BEGIN
				SELECT * FROM AutoApp.TypeClient
					WHERE AutoApp.TypeClient.TypeClientID = _TypeClientID;
		END;

