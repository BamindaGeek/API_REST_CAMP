create procedure ps_SelectOneTypeVehicule(IN `_TypeVehiculeID` varchar(255))
  BEGIN
				SELECT * FROM AutoApp.TypeVehicule
					WHERE AutoApp.TypeVehicule.TypeVehiculeID = _TypeVehiculeID;
		END;

