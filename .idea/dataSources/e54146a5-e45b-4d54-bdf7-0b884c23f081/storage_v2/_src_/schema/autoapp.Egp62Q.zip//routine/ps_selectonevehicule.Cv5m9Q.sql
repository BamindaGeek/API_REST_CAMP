create procedure ps_SelectOneVehicule(IN `_VehiculeID` varchar(255))
  BEGIN
				SELECT * FROM AutoApp.Vehicule
					WHERE AutoApp.Vehicule.VehiculeID = _VehiculeID;
		END;

