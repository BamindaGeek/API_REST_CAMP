create procedure ps_SelectOneVente(IN `_VenteID` varchar(255))
  BEGIN
				SELECT * FROM AutoApp.Vente
					WHERE AutoApp.Vente.VenteID = _VenteID;
		END;

