create procedure ps_Transaction(IN `_TransactionsID` varchar(255), IN `_Date` datetime, IN `_Montant` decimal,
                                IN `_ProduitID`      varchar(225), IN `_ClientID` varchar(225),
                                IN `_Action`         varchar(100))
  BEGIN
					IF (_Action = 'Insert') THEN
						INSERT INTO AutoApp.Transactions (_TransactionID,Date,Montant,Description,ClientID,VenteID,LocationID,VehiculeID)
							VALUES (_TransactionID,_Date,_Montant,_Description,_ClientID,_VenteID,_LocationID,_VehiculeID);
					END IF;
				    
				    IF (_Action = 'Update') THEN
						UPDATE AutoApp.Transactions
							SET AutoApp.Transactions.Date= _Date,
								AutoApp.Transactions.Montant = _Montant,
                                AutoApp.Transactions.Description = _Description,
                                AutoApp.Transactions.ClientID = _ClientID,
                                AutoApp.Transactions.VenteID = _VenteID,
                                AutoApp.Transactions.LocationID = _LocationID,
                                AutoApp.Transactions.VehiculeID = _VehiculeID
                           WHERE AutoApp.Transactions.TransactionsID = _TransactionsID;
					END IF;
				    
				    IF (_Action = 'Delete') THEN
						DELETE
							FROM AutoApp.Transactions
								WHERE  AutoApp.Transactions.TransactionsID = _TransactionsID;
					END IF;
				END;

