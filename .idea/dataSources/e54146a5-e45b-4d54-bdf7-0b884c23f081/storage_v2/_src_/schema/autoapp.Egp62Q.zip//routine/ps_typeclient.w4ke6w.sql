create procedure ps_TypeClient(IN `_TypeClientID` varchar(255), IN `_Libelle` varchar(255),
                               IN `_Description`  varchar(255), IN `_CritereID` varchar(255), IN `_Action` varchar(100))
  BEGIN
					IF (_Action = 'Insert') THEN
						INSERT INTO AutoApp.TypeClient (TypeClientID,Libelle, Description, CritereID)
							VALUES (_TypeClientID,_Libelle,_Description,_CritereID);
					END IF;
				    
				    IF (_Action = 'Update') THEN
						UPDATE AutoApp.TypeClient
							SET AutoApp.TypeClient.Libelle = _Libelle,
							    AutoApp.TypeClient.Description = _Description,
                                AutoApp.TypeClient.CritereID = _CritereID							
							WHERE AutoApp.TypeClient.TypeClientID = _TypeClientID;
					END IF;
				    
				    IF (_Action = 'Delete') THEN
						DELETE
							FROM AutoApp.TypeClient
								WHERE  AutoApp.TypeClient.TypeClientID = _TypeClientID;
					END IF;
				END;

