create procedure ps_TypeVehicule(IN `_TypeVehiculeID` varchar(255), IN `_Libelle` varchar(225),
                                 IN `_Description`    varchar(225), IN `_Action` varchar(100))
  BEGIN
					IF (_Action = 'Insert') THEN
						INSERT INTO AutoApp.TypeVehicule (TypeVehiculeID,Libelle,Description)
							VALUES (_TypeVehiculeID,_Libelle, _Description);
					END IF;
				    
				    IF (_Action = 'Update') THEN
						UPDATE AutoApp.TypeVehicule
							SET AutoApp.TypeVehicule.Libelle = _Libelle,
								AutoApp.TypeVehicule.Description = _Description
							WHERE AutoApp.TypeVehicule.TypeVehiculeID = _TypeVehiculeID;
					END IF;
				    
				    IF (_Action = 'Delete') THEN
						DELETE
							FROM AutoApp.TypeVehicule
								WHERE  AutoApp.TypeVehicule.TypeVehiculeID = _TypeVehiculeID;
					END IF;
				END;

