create procedure ps_Vente(IN `_VenteID` varchar(225), IN `_CampagneID` varchar(225), IN `_Action` varchar(100))
  BEGIN
					IF (_Action = 'Insert') THEN
						INSERT INTO AutoApp.Location (VenteID,CampagneID)
							VALUES (_VenteID,_CampagneID);
					END IF;
				    
				    IF (_Action = 'Update') THEN
						UPDATE AutoApp.Vente
                              set AutoApp.Vente.CampaganeID = _CampagneID
						WHERE AutoApp.Vente.VenteID = _VenteID;
					END IF;
				    
				    IF (_Action = 'Delete') THEN
						DELETE
							FROM AutoApp.Vente
								WHERE  AutoApp.Vente.VenteID = _VenteID;
					END IF;
				END;

